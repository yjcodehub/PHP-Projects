<?php 
	require_once 'config.php';
	require 'sessionUser.php';
	$userId = $_SESSION['userId'];
	extract($_GET);
	extract($_POST);
	$plantQuery = "SELECT * FROM plants WHERE plantId = '$plantId' AND deleted = 1";
	$flowerQuery = "SELECT * FROM flowers WHERE flowerId = '$flowerId' AND deleted = 1";
	$fertilizerQuery = "SELECT * FROM fertilizers WHERE fertilizerId = '$fertilizerId' AND deleted = 1";
	$accesoryQuery = "SELECT * FROM accesories WHERE accesoryId = '$accesoryId' AND deleted = 1";

	$plantResult = $con->query($plantQuery);
	$flowerResult = $con->query($flowerQuery);
	$fertilizerResult = $con->query($fertilizerQuery);
	$accesoryResult = $con->query($accesoryQuery);

	$plantData = $plantResult->fetch_object();
	$flowerData = $flowerResult->fetch_object();
	$fertilizerData = $fertilizerResult->fetch_object();
	$accesoryData = $accesoryResult->fetch_object();

	$todayDate = date('d/m/Y');
	$rand1 = rand(100, 999);
	$rand2 = rand(100, 999);
	$rand3 = rand(100, 999);
	$productNo = "$rand1-$rand2-$rand3"; //Random Number Gerator
	if(isset($plantId)){
		$query = "INSERT INTO cart VALUES(NULL, '$plantData->plantName', '$productNo', '$plantData->plantCost', '$todayDate', '$userId')";
		if ($con->query($query)) {
			echo "<script>alert('$plantData->plantName added to cart.')</script>";
			echo "<script>window.location.href='view/indoor.php'</script>";
		}
		else{
			echo mysqli_error($con);
		}
	}
	elseif(isset($flowerId)){
		$query = "INSERT INTO cart VALUES(NULL, '$flowerData->flowerName', '$productNo', '$flowerData->flowerCost', '$todayDate', '$userId')";
		if ($con->query($query)) {
			echo "<script>alert('$flowerData->flowerName added to cart.')</script>";
			echo "<script>window.location.href='view/rose.php'</script>";
		}
		else{
			echo mysqli_error($con);
		}
	}
	elseif(isset($fertilizerId)){
		$query = "INSERT INTO cart VALUES(NULL, '$fertilizerData->fertilizerName', '$productNo', '$fertilizerData->fertilizerCost', '$todayDate', '$userId')";
		if ($con->query($query)) {
			echo "<script>alert('$fertilizerData->fertilizerName added to cart.')</script>";
			echo "<script>window.location.href='view/organic.php'</script>";
		}
		else{
			echo mysqli_error($con);
		}
	}
	elseif(isset($accesoryId)){
		$query = "INSERT INTO cart VALUES(NULL, '$accesoryData->accesoryName', '$productNo', '$accesoryData->accesoryCost', '$todayDate', '$userId')";
		if ($con->query($query)) {
			echo "<script>alert('$accesoryData->accesoryName added to cart.')</script>";
			echo "<script>window.location.href='view/plate.php'</script>";
		}
		else{
			echo mysqli_error($con);
		}
	}
 ?>