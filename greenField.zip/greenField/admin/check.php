<?php 
	extract($_POST);
	require_once 'config.php';
	if (isset($adminLogin)) {
		$query = "SELECT * FROM admin WHERE adminEmail = '$email' and adminPassword ='$password'";
		$result = $con->query($query);
		$rows = mysqli_num_rows($result);
		$data = $result->fetch_object();
		if ($rows == 1) {
			session_start();
			$_SESSION['id'] = session_id();
			$_SESSION['adminId'] = $data->adminId;
			$_SESSION['adminName'] = $data->adminName;
			$_SESSION['adminEmail'] = $data->adminEmail;
			$_SESSION['adminPassword'] = $data->adminPassword;
			$_SESSION['adminMobile'] = $data->adminMobile;
			echo "<script>alert('You have logged in Successfully')</script>";
			echo "<script>window.location.href='dashboard.php'</script>";
		}
		else{
			echo "<script>alert('Email or Password Invalid')</script>";
			echo "<script>window.location.href='index.php'</script>";
		}
	}
 ?>