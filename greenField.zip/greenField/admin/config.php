<?php 
	$localhost = 'localhost';
	$username = 'root';
	$db_pass = '';
	$dbname = 'greenfield';

	$con = new mysqli($localhost, $username, $db_pass, $dbname);
 ?>