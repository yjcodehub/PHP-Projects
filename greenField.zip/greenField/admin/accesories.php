<?php 
  require_once 'config.php';
  require_once 'sessionAdmin.php';
  $query = "SELECT * FROM category WHERE categoryName = 'Accessories' and deleted = 1";
  $result = $con->query($query);
 ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GreenField | Nursary Home</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="dashboard/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- Select2 -->
  <link rel="stylesheet" href="dashboard/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="dashboard/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dashboard/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="dashboard/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="dashboard/plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <style type="text/css">
    *{
      font-family: roboto;
    }
    .back{
      background: url(img/flower.png) no-repeat fixed;
      background-size: cover;
    }
    .imp{
      color: #f00;
    }
    .imageSize{
      width: 100%;
      height: 200px;
    }
    .backGreen{
      background-color: #D0CDE1;
      padding: 5px;
      border: 1px solid #000;
      box-shadow: 0px 2px 2px #000
    }
    div.row  h1.text-center{
      background-color: #FFE9BD;
      border: 1px solid #000;
      border-radius: 10px;
      text-shadow: 1px 1px 5px #000;
      box-shadow: 0px 2px 3px #000;
    }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="logout.php" class="nav-link btn btn-danger btn-sm text-white">Logout</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="dashboard.php" class="brand-link">
      <img src="img/g-symbol.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><span style="color: #0f0;">GREEN</span>FIELD</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dashboard/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $_SESSION['adminName']?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="category.php" class="nav-link">
              <i class="nav-icon fas fa-cog"></i>
              <p>
                Set Category
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-bars"></i>
              <p>
                Add Products
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="plants.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Plants</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="flowers.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Flowers</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="fertilizers.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Fertilizers</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="accesories.php" class="nav-link active">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Accesories</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="info.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-danger"></i>
                  <p>Detail Information</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="userList.php" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Users List
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="userFeedback.php" class="nav-link">
              <i class="nav-icon fas fa-comments"></i>
              <p>
                Users Feedback
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="userEnquiry.php" class="nav-link">
              <i class="nav-icon fas fa-comment-alt"></i>
              <p>
                Users Enquiry
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="purchased.php" class="nav-link">
              <i class="nav-icon fas fa-shopping-cart"></i>
              <p>
                Purchased List
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper back">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add Accesories</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
              <li class="breadcrumb-item active">Add Products</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- <div class="col-md-6"></div> -->
            <div class="card card-info col-md-4">
              <div class="card-header">
                <h3 class="card-title">Add Accesories Product</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="getdata.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="plant_name">Name of Accesory<sup><span class="imp">*</span></sup></label>
                    <input type="text" name="accesoryName" class="form-control" id="plant_name" placeholder="Enter Accesory Name" required>
                  </div>
                  <div class="form-group">
                    <label>Select Sub-Category<sup><span class="imp">*</span></sup></label>
                    <select class="form-control select2" name="categoryId" style="width: 100%;" required>
                      <?php 
                        while ($data = $result->fetch_object()) {
                          echo "<option value='$data->categoryId'>$data->subCategoryName</option>";
                        }
                       ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="productCost">Product Cost<sup><span class="imp">*</span></sup></label>
                    <input type="text" name="accesoryCost" class="form-control" id="productCost" placeholder="Enter Cost" required>
                  </div>
                  <div class="form-group">
                    <label for="productImage">Upload Product Image<sup><span class="imp">*</span></sup></label>
                    <input type="file" name="image" class="form-control" id="productImage" placeholder="Enter sub category" required>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="accesorySubmit" class="btn btn-success">Submit</button>
                  <button type="reset" class="btn btn-danger">Cancel</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
        </div><!-- /.row -->
        <?php 
          $query = "
            SELECT * FROM accesories as a
            INNER JOIN category as c
            ON a.category_id = c.categoryId
            WHERE a.deleted = 1
           ";
           $plateResult = $con->query($query);
           $potResult = $con->query($query);
         ?>
         <!-- Organic Fertilizer List -->
         <div class="row">
            <div class="col-sm-12">
              <h1 class="text-dark text-center mb-2">Plates</h1>
            </div>
            <div class="col-sm-12">
              <div class="row">
                <?php
                while ($plateData = $plateResult->fetch_object()) {
                  if($plateData->category_id == 15){
                    echo "<div class='col-sm-6 col-md-2'>";
                     echo "<div class='card'>";
                      echo "<img src='uploads/accesories/plates/$plateData->accesoryImage' alt='$plateData->accesoryName' class='imageSize'>";
                        echo "<div class='backGreen'>";
                          echo "<div class='caption'>";
                            echo "<h5>$plateData->accesoryName</h5>";
                            echo "<p>Accesory cost is : <b>$plateData->accesoryCost Rs</b></p>";
                            echo "<p><a href='editAccesories.php?accesoryId=$plateData->accesoryId' class='btn btn-success btn-sm' role='button'>Edit</a> <a href='delete.php?accesoryId=$plateData->accesoryId' class='btn btn-danger btn-sm' role='button'>Delete</a></p>";
                          echo "</div>";
                        echo "</div>";
                      echo "</div>";
                    echo "</div>";
                  }
                }
                ?>
              </div>
            </div>
         </div>  <!--/. Organic Fertilizer List -->

         <!-- Inorganic Fertilizer List -->
         <div class="row">
            <div class="col-sm-12">
              <h1 class="text-dark text-center mb-2">Pots</h1>
            </div>
            <div class="col-sm-12">
              <div class="row">
                <?php
                while ($potData = $potResult->fetch_object()) {
                  if($potData->category_id == 16){
                    echo "<div class='col-sm-6 col-md-2'>";
                     echo "<div class='card'>";
                      echo "<img src='uploads/accesories/pots/$potData->accesoryImage' alt='$potData->accesoryName' class='imageSize'>";
                        echo "<div class='backGreen'>";
                          echo "<div class='caption'>";
                            echo "<h5>$potData->accesoryName</h5>";
                            echo "<p>Accesory cost is : <b>$potData->accesoryCost Rs</b></p>";
                            echo "<p><a href='editAccesories.php?accesoryId=$potData->accesoryId' class='btn btn-success btn-sm' role='button'>Edit</a> <a href='delete.php?accesoryId=$potData->accesoryId' class='btn btn-danger btn-sm' role='button'>Delete</a></p>";
                          echo "</div>";
                        echo "</div>";
                      echo "</div>";
                    echo "</div>";
                  }
                }
                ?>
              </div>
            </div>
         </div>  <!--/. Inorganic Fertilizer List -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php 
    require_once 'footer.php';
   ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="dashboard/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="dashboard/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2();
  })
</script>
<!-- Select2 -->
<script src="dashboard/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap 4 -->
<script src="dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="dashboard/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="dashboard/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="dashboard/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="dashboard/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="dashboard/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="dashboard/plugins/moment/moment.min.js"></script>
<script src="dashboard/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="dashboard/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="dashboard/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dashboard/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dashboard/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dashboard/dist/js/demo.js"></script>
</body>
</html>
