-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2021 at 08:23 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `proj_unusedmed`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', 'Admin@1234');

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

CREATE TABLE `assign` (
  `id` bigint(11) NOT NULL,
  `assign_by` bigint(11) NOT NULL,
  `assign_to` bigint(11) NOT NULL,
  `collect_from` bigint(11) NOT NULL,
  `assign_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`id`, `assign_by`, `assign_to`, `collect_from`, `assign_date`, `created_at`, `modified_at`, `deleted_at`) VALUES
(2, 1, 1, 2, '2021-06-20', '2021-06-18 08:50:29', '2021-06-18 08:50:29', 1),
(3, 4, 4, 5, '2021-06-21', '2021-06-18 10:19:45', '2021-06-18 10:19:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `collector`
--

CREATE TABLE `collector` (
  `id` bigint(11) NOT NULL,
  `mrName` varchar(50) NOT NULL,
  `mrAge` int(5) NOT NULL,
  `mrEmail` varchar(255) NOT NULL,
  `mrPassword` varchar(255) NOT NULL,
  `mrAddress1` varchar(255) NOT NULL,
  `mrAddress2` varchar(255) NOT NULL,
  `mrCity` varchar(50) NOT NULL,
  `mrMobile` bigint(15) NOT NULL,
  `mrAdhar` bigint(15) NOT NULL,
  `mrImage` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collector`
--

INSERT INTO `collector` (`id`, `mrName`, `mrAge`, `mrEmail`, `mrPassword`, `mrAddress1`, `mrAddress2`, `mrCity`, `mrMobile`, `mrAdhar`, `mrImage`, `user_id`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 'Shubham Jais', 22, 'shubham@gmail.com', '789', 'Juni Shukrawari', 'Near Gandhi Statue', 'Nagpur', 7528529520, 745898561254, 'wrushabhDigitalArt.jpg', 1, '2021-06-15 06:47:26', '2021-06-15 06:47:26', 1),
(2, 'Kunal Jais', 27, 'kunal@gmail.com', '456', 'Juni Mangalwari', 'Near Itwari chowk', 'Nagpur', 7418529637, 741523985542, 'images (47).jpg', 1, '2021-06-16 06:41:53', '2021-06-16 07:50:17', 1),
(3, 'Purshotaam', 55, 'purushottam@gmail.com', '123456', 'Manewada', 'Tukdoji Putla', 'Nagpur', 7020437966, 741582639000, 'girl3.jpg', 3, '2021-06-18 08:21:11', '2021-06-18 08:21:11', 1),
(4, 'Vibha Gomase', 22, 'vibha@gmail.com', 'Vibha@1234', 'Bhandara', 'Gadchiroli', 'Nagpur', 7020437966, 784512369598, 'noshin2.jpg', 4, '2021-06-18 09:58:53', '2021-06-18 10:00:13', 1),
(5, 'Snehal Gharad', 23, 'snehal@gmail.com', 'Snehal@1234', 'Tumsar', 'umred', 'Nagpur', 7415263980, 784512364664, 'Hanuman 3.jpg', 4, '2021-06-18 10:03:14', '2021-06-18 10:03:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `donations`
--

CREATE TABLE `donations` (
  `id` bigint(11) NOT NULL,
  `ngo_id` bigint(11) NOT NULL,
  `medBrand` varchar(100) NOT NULL,
  `medName` varchar(255) NOT NULL,
  `medType` varchar(50) NOT NULL,
  `mfgDate` date NOT NULL,
  `expDate` date NOT NULL,
  `mfgImage` varchar(255) NOT NULL,
  `expImage` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donations`
--

INSERT INTO `donations` (`id`, `ngo_id`, `medBrand`, `medName`, `medType`, `mfgDate`, `expDate`, `mfgImage`, `expImage`, `user_id`, `status`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 1, 'Snehal Pharma & Surgicals Pvt. Ltd.', 'Paracetamol', 'tablet', '2020-11-20', '2021-11-20', 'paracetamol.jpg', 'expDate paracetamol.jpg', 2, 4, '2021-06-17 16:19:04', '2021-06-18 08:50:29', 1),
(2, 1, 'Azee 500', 'Azee 500', 'tablet', '2021-01-11', '2021-12-11', 'azee500.jpg', 'exp_azee.jpg', 2, 0, '2021-06-17 16:24:05', '2021-06-17 17:54:51', 1),
(3, 3, 'Solvin cold', 'Solvin Cold', 'syrup', '2021-02-20', '2021-07-20', 'solvin cold.jpg', 'solvin cold exp.jpg', 2, 2, '2021-06-17 17:01:32', '2021-06-18 08:19:30', 1),
(4, 5, 'Solvin cold', 'Solvin Cold', 'syrup', '2021-06-18', '2021-11-20', 'solvin cold.jpg', 'solvin cold exp.jpg', 5, 4, '2021-06-18 10:11:11', '2021-06-18 10:19:45', 1),
(5, 5, 'Azee 500', 'alzer 500', 'tablet', '2021-06-08', '2021-08-11', 'azee500.jpg', 'exp_azee.jpg', 5, 1, '2021-06-18 10:14:31', '2021-06-18 10:14:31', 1),
(6, 5, 'Injection', 'injection', 'injection', '2021-06-08', '2021-07-11', 'tetnus.jpg', 'tetnus exp date.jpg', 5, 2, '2021-06-18 10:15:28', '2021-06-18 10:20:51', 1),
(7, 5, 'Moxi D', 'Moxi D Eye Drop', 'drop', '2021-03-16', '2021-10-13', 'moxi d.png', 'moxi d exp date.jpg', 5, 0, '2021-06-18 10:16:23', '2021-06-18 10:21:02', 1),
(8, 5, 'Patanajali', 'Drishti', 'drop', '2021-06-02', '2021-08-19', 'IMG-20210608-WA0021.jpg', 'IMG_20210617_122022.jpg', 5, 1, '2021-06-18 17:01:49', '2021-06-18 17:01:49', 1),
(9, 5, 'Patanajali', 'Drishti', 'drop', '2021-06-02', '2021-08-19', 'IMG-20210608-WA0021.jpg', 'IMG_20210617_122022.jpg', 5, 1, '2021-06-18 17:01:57', '2021-06-18 17:01:57', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ngo`
--

CREATE TABLE `ngo` (
  `id` bigint(11) NOT NULL,
  `ngoName` varchar(100) NOT NULL,
  `ngoAddress1` varchar(100) NOT NULL,
  `ngoAddress2` varchar(100) NOT NULL,
  `ngoCity` varchar(50) NOT NULL,
  `ngoMobile` bigint(15) NOT NULL,
  `ngoWebsite` varchar(100) DEFAULT NULL,
  `user_id` bigint(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo`
--

INSERT INTO `ngo` (`id`, `ngoName`, `ngoAddress1`, `ngoAddress2`, `ngoCity`, `ngoMobile`, `ngoWebsite`, `user_id`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 'Foundation', 'Dighori', 'Near Dighori naka', 'Nagpur', 7539514562, 'https://www.foundation.com', 1, '2021-06-11 06:37:15', '2021-06-11 06:37:15', 1),
(2, 'Krafton', 'Super market', 'Near Gangotri School', 'Delhi', 7585964595, NULL, 1, '2021-06-12 17:38:11', '2021-06-12 17:38:11', 1),
(3, 'Rebel Founcation', 'Kanchivissa', 'Wardhaman Nagar', 'Nagpur', 7485962130, 'https://www.rebel.com', 3, '2021-06-12 17:42:05', '2021-06-12 17:42:05', 1),
(5, 'Skyline Foundation', 'Hingna', 'Near T-point', 'Nagpur', 7418529630, 'https://www.skylinefoundation.com', 4, '2021-06-18 09:50:28', '2021-06-18 09:50:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ngo_desc`
--

CREATE TABLE `ngo_desc` (
  `id` bigint(11) NOT NULL,
  `ngo_id` bigint(11) NOT NULL,
  `branch` varchar(100) DEFAULT NULL,
  `members` int(7) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `award` text DEFAULT NULL,
  `awardImage` varchar(100) DEFAULT NULL,
  `achievements` text DEFAULT NULL,
  `successStory` text DEFAULT NULL,
  `successStoryImage` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ngo_desc`
--

INSERT INTO `ngo_desc` (`id`, `ngo_id`, `branch`, `members`, `description`, `award`, `awardImage`, `achievements`, `successStory`, `successStoryImage`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 1, 'Nandanvan', 50, 'This foundation NGO was inaugurated by Sachin Tendulkar since 1980.\r\nNow we are running this NGO in huge amount of donations.', '1. 1st in Donation of cloths\r\n2. 1st in Donation wheel chair', 'wheel1.jpg', '1. 1st in Donation of cloths\r\n2. 1st in Donation wheel chair', '    Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis corporis, et amet ullam a maiores ratione ut commodi quibusdam laborum neque optio quisquam provident excepturi in assumenda, ipsum repellat hic.\r\n', 'cloth1.jpg', '2021-06-13 15:17:50', '2021-06-13 15:17:50', 1),
(2, 5, 'Mahal', 100, 'NGO is started from 1987 and it is biggest NGO in NAGPUR.', '1. 1st in painting event\r\n2. 2nd in  sketching Event', 'solvin cold exp.jpg', '1. Donated 100 wheel chairs', 'NGO is helping to many poor people', 'wheel2.jpg', '2021-06-18 09:55:42', '2021-06-18 09:55:42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` tinyint(1) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role`) VALUES
(1, 'NGO'),
(2, 'Donor');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `age` int(5) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `mobile` bigint(15) NOT NULL,
  `adhar` bigint(16) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `role_id` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `age`, `email`, `password`, `address1`, `address2`, `city`, `mobile`, `adhar`, `image`, `role_id`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 'Yash Jais', 24, 'yash@gmail.com', '123', 'Juni Shukrawari', 'Near Shahu Samaj bhavan', 'Nagpur', 7020437966, 434682869749, 'Image from iOS.jpg', 1, '2021-06-08 19:43:47', '2021-06-08 19:43:47', 1),
(2, 'Roshni Jais', 25, 'roshni@gmail.com', '456', 'Bhaji Mandi', 'Near Shahu Samaj bhavan', 'Nagpur', 7418529630, 789456123654, 'Rashmika Digital Art.jpg', 2, '2021-06-08 19:45:41', '2021-06-08 19:45:41', 1),
(3, 'Shurti Jaiswal', 25, 'shrutijaiswal@gmail.com', '789', 'Gharich', 'Opp. gandhiji', 'Nagpur', 7894561230, 963254178596, 'girl5.png', 1, '2021-06-12 17:40:43', '2021-06-12 17:40:43', 1),
(4, 'Pallavi bondre', 22, 'pallavi@gmail.com', 'Pallavi@1234', 'Bhandara', 'Tumsar', 'Nagpur', 7894561230, 785441344534, 'girl1.jpg', 1, '2021-06-18 09:45:15', '2021-06-18 09:45:15', 1),
(5, 'Trupti Kulbhaje', 22, 'trupti@gmail.com', 'Trupti@1234', 'Plot No. 456 Tumsar', 'Near Bhandara', 'Nagpur District', 7539514562, 745896321466, 'noshin.jpg', 2, '2021-06-18 10:06:26', '2021-06-18 10:06:26', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `assign`
--
ALTER TABLE `assign`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collector`
--
ALTER TABLE `collector`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donations`
--
ALTER TABLE `donations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ngo`
--
ALTER TABLE `ngo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ngo_desc`
--
ALTER TABLE `ngo_desc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `assign`
--
ALTER TABLE `assign`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `collector`
--
ALTER TABLE `collector`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `donations`
--
ALTER TABLE `donations`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ngo`
--
ALTER TABLE `ngo`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ngo_desc`
--
ALTER TABLE `ngo_desc`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` tinyint(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
