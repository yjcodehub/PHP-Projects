<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="dashboard.php" class="brand-link">
    <img src="../public/_img/medicine2.png" alt="medicine2" class="brand-image" style="opacity: .8">
    <span class="brand-text font-weight-light">u.Medicine Donation</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <?php
    if ($_SESSION['session_admin'] == "umdSessionAdmin") {
    ?>
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../public/dashboard/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $_SESSION['admin_name'] ?></a>
        </div>
      </div>
    <?php
    } elseif ($_SESSION['session_ngo_owner'] == "umdSessionNGOOwner") {
    ?>
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../public/_uploads/<?php echo $_SESSION['ngo_owner_image'] ?>" class="img-circle elevation-2" alt="User Image" width="34" height="34">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $_SESSION['ngo_owner_name'] ?></a>
        </div>
      </div>
    <?php
    } elseif ($_SESSION['session_donor'] == "umdSessionDonor") {
    ?>
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../public/_uploads/<?php echo $_SESSION['donor_image'] ?>" class="img-circle elevation-2" alt="User Image" width="34" height="34">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $_SESSION['donor_name'] ?></a>
        </div>
      </div>
    <?php
    }
    ?>


    <!-- 
        Sidebar search form if neccesary then add
       -->

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
        <?php
        if ($_SESSION['session_admin'] == "umdSessionAdmin") {
        ?>
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item menu-close">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Users
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="manage_ngo_owner.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>NGO Owners</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_donor.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Donors</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="manage_ngo.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-heart"></i>
              <p>
                NGOs
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_collectors.php" class="nav-link">
              <i class="nav-icon fas fa-user-plus"></i>
              <p>
                Collectors
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_donations.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-medical"></i>
              <p>
                Donations
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="manage_accepted.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-primary"></i>
                  <p>Accepted Request</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_declined.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-danger"></i>
                  <p>Declined Request</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_assigned.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-info"></i>
                  <p>Assigned Request</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_pending.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-warning"></i>
                  <p>Pending Request</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="manage_medicines.php" class="nav-link">
              <i class="fas fa-pills nav-icon"></i>
              <p>Medicines</p>
            </a>
          </li>
        <?php
        } elseif ($_SESSION['session_ngo_owner'] == "umdSessionNGOOwner") {
        ?>
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="create_ngo.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-heart"></i>
              <p>
                Add NGO
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_ngo.php" class="nav-link">
              <i class="nav-icon fas fa-list"></i>
              <p>
                Manage NGO
              </p>
            </a>
          </li>
          <li class="nav-item ">
            <a href="manage_collector.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Collectors
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="create_collector.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Create Collectors</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="manage_collectors.php" class="nav-link">
                  <i class="far fa-circle nav-icon text-success"></i>
                  <p>Manage Collectors</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item">
            <a href="manage_donors.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-medical"></i>
              <p>
                Donors
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_donations.php" class="nav-link">
              <i class="nav-icon fas fa-clipboard-list"></i>
              <p>
                Manage Donations
              </p>
            </a>
          </li>
        <?php
        } elseif ($_SESSION['session_donor'] == "umdSessionDonor") {
        ?>
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_ngo.php" class="nav-link">
              <i class="nav-icon fas fa-hand-holding-heart"></i>
              <p>
                NGOs
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="manage_donations.php" class="nav-link">
              <i class="nav-icon fas fa-clipboard-list"></i>
              <p>
                Manage Donations
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="accepted_donations.php" class="nav-link">
              <i class="nav-icon fas fa-check"></i>
              <p>
                Accepted Request
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="declined_donations.php" class="nav-link">
              <i class="nav-icon fas fa-times"></i>
              <p>
                Decline Request
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="assigned_donations.php" class="nav-link">
              <i class="nav-icon fas fa-handshake"></i>
              <p>
                Assigned Request
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="pending_donations.php" class="nav-link">
              <i class="nav-icon fas fa-hourglass-half"></i>
              <p>
                Pending Request
              </p>
            </a>
          </li>
        <?php
        }
        ?>

      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>