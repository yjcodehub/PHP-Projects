<?php
require_once 'config/config.php';
class Database
{
  private $localhost = DB_HOST;
  private $username = DB_USER;
  private $password = DB_PWD;
  private $dbname = DB_NAME;

  private $connection;
  private $error;
  private $stmt;
  private $dbconnected = true;

  function __construct()
  {
    $dbm = "mysql:localhost=$this->localhost;dbname=$this->dbname";
    $option = array(
      PDO::ATTR_PERSISTENT => true,
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    );
    try {
      $this->connection = new PDO($dbm, $this->username, $this->password, $option);
      $this->dbconnected = true;
    } catch (PDOException $e) {
      $this->error = $e->getMessage() . "<br>";
      $this->dbconnected = false;
    }
  }

  /* 
   * Function to get Error
  */
  function getError()
  {
    return $this->error;
  }
  /* 
   * Function to display connection whether it is connected or not
  */
  function isConnected()
  {
    return $this->dbconnected;
  }
  /* 
   * Function to prepare query for execution
  */
  function query($query)
  {
    $this->stmt = $this->connection->prepare($query);
  }
  /* 
   * Function to execute the query
  */
  function execute()
  {
    return $this->stmt->execute();
  }
  /* 
   * Function to fetch All data
  */
  function resultSet()
  {
    $this->execute();
    return $this->stmt->fetchALL(PDO::FETCH_OBJ);
  }
  /* 
   * Function to get single data
  */
  function single()
  {
    $this->execute();
    return $this->stmt->fetch(PDO::FETCH_OBJ);
  }
  /* 
   * Function to count rows
  */
  function rowCount()
  {
    $this->execute();
    return $this->stmt->rowCount();
  }
  /* 
   * Function to setup value type
  */
  function bind($param, $value, $type = null)
  {
    if ($type == null) {
      switch (true) {
        case is_null($value):
          $type = PDO::PARAM_NULL;
          break;

        case is_int($value):
          $type = PDO::PARAM_INT;
          break;

        case is_bool($value):
          $type = PDO::PARAM_BOOL;
          break;

        default:
          $type = PDO::PARAM_STR;
          break;
      }
    }
    $this->stmt->bindValue($param, $value, $type);
  }
}
