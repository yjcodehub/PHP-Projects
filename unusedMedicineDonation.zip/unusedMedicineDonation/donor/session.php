<?php
error_reporting(0);
session_id("umdSessionDonor");
session_start();
$id = session_id();
if ($id != $_SESSION['session_donor']) {
  session_destroy();
  echo "<script>alert('Please login first')</script>";
  echo "<script>window.location.href='../index.php'</script>";
}
