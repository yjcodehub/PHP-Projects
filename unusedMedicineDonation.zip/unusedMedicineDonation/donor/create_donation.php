<?php
require_once "session.php";
require_once "../model/Ngo.php";
$ngo = new Ngo();
$data = $ngo->read_single_ngo($_GET['ngo_id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | Donor</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="../public/dashboard/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Create Donations </h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Add donation</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-md-8 offset-md-2">
              <div class="card elevation-3 card-success">
                <div class="card-header">
                  <h1 class="card-title">Add Donation</h1>
                </div>
                <form action="../controller/DonorController.php" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="form-group">
                      <label for="NGOname">Name of NGO <sup class="text-danger">*</sup></label>
                      <input type="hidden" name="ngo_id" value="<?php echo $data->id ?>">
                      <input type="text" name="ngo_name" id="NGOname" class="form-control" value="<?php echo $data->ngoName ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="Brand">Medicine Brand <sup class="text-danger">*</sup></label>
                      <input type="text" name="brand" id="Brand" class="form-control" placeholder="Medicine Brand">
                    </div>
                    <div class="form-group">
                      <label for="Name">Medicine Name <sup class="text-danger">*</sup></label>
                      <input type="text" name="name" id="Name" class="form-control" placeholder="Medicine Name">
                    </div>
                    <div class="form-row mt-4">
                      <div class="form-group col-md-4">
                        <label for="Type">Medicine Type <sup class="text-danger">*</sup></label>
                        <select name="type" id="Type" class="form-control select2">
                          <option value="Null" disabled>Select Medicine Type</option>
                          <option value="tablet">Tablet</option>
                          <option value="syrup">Syrup</option>
                          <option value="capsule">Capsule</option>
                          <option value="injection">Injection</option>
                          <option value="drop">Drops</option>
                          <option value="vaccine">Vaccne</option>
                        </select>
                      </div>
                      <div class="form-group col-md-4">
                        <label for="MFGDate">MFG. Date <sup class="text-danger">*</sup></label>
                        <input type="date" name="mfg_date" id="MFGDate" class="form-control">
                      </div>
                      <div class="form-group col-md-4">
                        <label for="EXPDate">EXP. Date <sup class="text-danger">*</sup></label>
                        <input type="date" name="exp_date" id="EXPDate" class="form-control">
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="form-group col-md-6">
                        <label for="MedImage">Medicine Image <sup class="text-danger">*</sup></label>
                        <input type="file" name="med_image" id="MedImage" class="form-control-file">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="EXPDateImage">EXP. Date Image <sup class="text-danger">*</sup></label>
                        <input type="file" name="exp_image" id="EXPDateImage" class="form-control-file">
                      </div>
                    </div>
                    <div class="form-group">
                      <input type="hidden" name="user_id" value="<?php echo $_SESSION['donor_id'] ?>">
                    </div>
                  </div>
                  <hr>
                  <div class="card-footer bg-white">
                    <input type="submit" name="donation_submit" class="btn btn-success" value="Donate">
                    <input type="reset" class="btn btn-danger" value="Cancel">
                  </div>
                </form>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>
  <!-- Select2 -->
  <script src="../public/dashboard/plugins/select2/js/select2.full.min.js"></script>


  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
  <!-- Page specific script -->
  <script>
    $(function() {
      //Initialize Select2 Elements
      $('.select2').select2()
    });
  </script>
</body>

</html>