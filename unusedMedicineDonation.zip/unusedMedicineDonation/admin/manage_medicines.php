<?php
require_once "session.php";
require_once "../model/Admin.php";
$admin = new Admin();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | Admin</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">View Medicines</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Medicines</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">View Donated Medicine List</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Sr No.</th>
                        <th>Medicine Brand</th>
                        <th>Medicine Name</th>
                        <th>Medicine Type</th>
                        <th>Expiry Date</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <?php
                    $data = $admin->medicine_details(0); //array format
                    $count = 0;
                    foreach ($data as $medicineData) {
                    ?>
                      <tr>
                        <td><?php echo ++$count ?></td>
                        <td><strong><?php echo $medicineData->medBrand ?></strong></td>
                        <td><?php echo $medicineData->medName ?></td>
                        <td><?php echo $medicineData->medType ?></td>
                        <td><?php echo $medicineData->expDate ?></td>
                        <td>
                          <a href="view.php?view_id=<?php echo $medicineData->id ?>" class="btn btn-primary"><i class="fa fa-eye fa-sm"></i> View</a>
                        </td>
                      </tr>
                    <?php
                    }
                    ?>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
  <!-- DataTables  & Plugins -->
  <script src="../public/dashboard/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/jszip/jszip.min.js"></script>
  <script src="../public/dashboard/plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../public/dashboard/plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <!-- Page Script -->
  <script>
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print"] //, colvis
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  </script>
</body>

</html>