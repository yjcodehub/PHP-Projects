<?php
require_once "session.php";
require_once "../model/Register.php";
require_once "../model/Admin.php";
$user = new Register();
$admin = new Admin();
$totalUser = $user->count_users();
$total_ngo = $admin->total_count("ngo");
$total_collector = $admin->total_count("collector");
$total_donations = $admin->total_count("donations");
$total_accepted = $admin->total_request("donations", 2);
$total_declined = $admin->total_request("donations", 0);
$total_assigned = $admin->total_request("donations", 4);
$total_pending = $admin->total_request("donations", 1);
$total_medicine = $admin->total_medicine("donations", 4);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | Admin</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Dashboard</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_ngo_owner.php" class="text-dark">
                <div class="info-box">
                  <span class="info-box-icon bg-info elevation-2"><i class="fas fa-users"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Total Users</span>
                    <span class="info-box-number">
                      <?php echo $totalUser ?>
                    </span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
              <!-- /.Redirect -->
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_ngo.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-danger elevation-2"><i class="fas fa-hand-holding-heart"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Total NGO's</span>
                    <span class="info-box-number"><?php echo $total_ngo ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->

            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_collectors.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-success elevation-2"><i class="fas fa-user-plus"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Collectors</span>
                    <span class="info-box-number"><?php echo $total_collector ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_donations.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-warning elevation-2"><i class="fas fa-hand-holding-medical"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Total Donations</span>
                    <span class="info-box-number"><?php echo $total_donations ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_accepted.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-indigo elevation-2"><i class="fas fa-check"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Accepted Request</span>
                    <span class="info-box-number"><?php echo $total_accepted ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_declined.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-teal elevation-2"><i class="fas fa-times"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Decline Request</span>
                    <span class="info-box-number"><?php echo $total_declined ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_assigned.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-navy elevation-2"><i class="fas fa-check"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Assigned Request</span>
                    <span class="info-box-number"><?php echo $total_assigned ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_pending.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-maroon elevation-2"><i class="fas fa-hourglass-half"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Pending Request</span>
                    <span class="info-box-number"><?php echo $total_pending ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <a href="manage_medicines.php" class="text-dark">
                <div class="info-box mb-3">
                  <span class="info-box-icon bg-primary elevation-2"><i class="fas fa-pills"></i></span>

                  <div class="info-box-content">
                    <span class="info-box-text">Medicines</span>
                    <span class="info-box-number"><?php echo $total_medicine ?></span>
                  </div>
                  <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
              </a>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
</body>

</html>