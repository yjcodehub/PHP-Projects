
<?php
require_once "../model/Donor.php";
extract($_POST);
extract($_GET);
extract($_FILES);
$donor = new Donor();
if (isset($donation_submit)) {
  $data = array(
    "ngo_id" => $ngo_id,
    "brand" => $brand,
    "name" => $name,
    "type" => $type,
    "mfg_date" => $mfg_date,
    "exp_date" => $exp_date,
    "med_image" => $med_image['name'],
    "exp_image" => $exp_image['name'],
    "user_id" => $user_id
  );
  $destination1 = "../public/_uploads/medicines/" . $med_image['name'];
  $destination2 = "../public/_uploads/medicines/" . $exp_image['name'];
  if (move_uploaded_file($med_image['tmp_name'], $destination1) && move_uploaded_file($exp_image['tmp_name'], $destination2)) {
    $donor->add_donation($data);
  } else {
    echo "<script>alert('Images doesn't uploaded. Please verify')</script>";
    echo "<script>window.history.back()</script>";
  }
} elseif (isset($donate_id)) {
  if (isset($accept)) {
    $donor->accept_request($donate_id);
  } else {
    $donor->decline_request($donate_id);
  }
}
