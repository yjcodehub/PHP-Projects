<?php
require_once "../model/Ngo.php";
extract($_POST);
extract($_GET);
extract($_FILES);
$ngo = new Ngo();
if (isset($ngo_submit)) {
  $data = array(
    "ngo_name" => $ngo_name,
    "add1" => $add1,
    "add2" => $add2,
    "city" => $city,
    "mobile" => $mobile,
    "website" => $website,
    "user_id" => $user_id
  );
  $ngo->add_data($data);
} elseif (isset($ngo_detail_submit)) {
  $data = array(
    "ngo_id" => $ngo_id,
    "branch" => $branch,
    "members" => $members,
    "description" => $description,
    "awards" => $awards,
    "awardImage" => $awardImage['name'],
    "achievement" => $achievement,
    "successStory" => $successStory,
    "sstImage" => $sstImage['name']
  );
  /*  echo "<pre>";
  print_r($_FILES);
  print_r($_POST); */
  $destinaion1 = "../public/_uploads/awards/" . $awardImage['name'];
  $destinaion2 = "../public/_uploads/success_story/" . $sstImage['name'];
  if (move_uploaded_file($awardImage['tmp_name'], $destinaion1) && move_uploaded_file($sstImage['tmp_name'], $destinaion2)) {
    $ngo->add_ngo_details($data);
  } else {
    echo "Images not uploaded";
  }
}
