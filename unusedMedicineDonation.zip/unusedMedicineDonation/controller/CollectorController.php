
<?php
require_once "../model/Collector.php";
extract($_POST);
extract($_GET);
extract($_FILES);
$collector = new Collector();
if (isset($collector_submit)) {
  $data = array(
    "name" => $name,
    "age" => $age,
    "email" => $email,
    "pass" => $pass,
    "add1" => $add1,
    "add2" => $add2,
    "city" => $city,
    "mobile" => $mobile,
    "adhar" => $adhar,
    "image" => $image['name'],
    "user_id" => $user_id
  );
  $destination = "../public/_uploads/" . $image['name'];
  if (move_uploaded_file($image['tmp_name'], $destination)) {
    $collector->add_collector($data);
  } else {
    echo "<script>alert('Something Went Wrong')</script>";
    echo "<script>window.history.back()</script>";
  }
} elseif (isset($collector_update)) {
  $data = array(
    "name" => $name,
    "age" => $age,
    "email" => $email,
    "add1" => $add1,
    "add2" => $add2,
    "city" => $city,
    "mobile" => $mobile,
    "adhar" => $adhar,
    "collector_id" => $collector_id
  );
  $collector->update_collector($data);
} elseif (isset($collector_delete)) {
  $collector->delete_collector($collector_delete);
} elseif (isset($assign_submit)) {
  $data = array(
    "assign_by" => $assign_by,
    "assign_to" => $assign_to,
    "collect_from" => $collect_from,
    "assign_date" => $assign_date,
    "donate_id" => $donate_id
  );
  $collector->create_assign($data);
}
