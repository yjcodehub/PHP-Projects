
<?php
require_once "../model/Register.php";
require_once "../model/Admin.php";
extract($_POST);
extract($_GET);
extract($_FILES);
$user = new Register();
$admin = new Admin();
if (isset($registerSubmit)) {
  $data = array(
    "name" => $name,
    "age" => $age,
    "email" => $email,
    "pass" => $pass,
    "add1" => $add1,
    "add2" => $add2,
    "city" => $city,
    "mobile" => $mobile,
    "adhar" => $adhar,
    "image" => $image['name'],
    "role_id" => $role_id
  );
  $destination = "../public/_uploads/" . $image['name'];
  if (move_uploaded_file($image['tmp_name'], $destination)) {
    $user->addData($data);
  }
} elseif (isset($ngo_user_id)) {
  if ($deleted_at == 1) {
    $admin->status_block_ngo_user($ngo_user_id);
  } else {
    $admin->status_unblock_ngo_user($ngo_user_id);
  }
} elseif (isset($donor_user_id)) {
  if ($deleted_at == 1) {
    $admin->status_block_donor_user($donor_user_id);
  } else {
    $admin->status_unblock_donor_user($donor_user_id);
  }
}
