<?php
require_once "../model/Admin.php";
require_once "../model/Register.php";
extract($_POST);
extract($_GET);
extract($_FILES);
$admin = new Admin();
$user = new Register();
if (isset($loginSubmit)) {
  $adminData = $admin->singleData(1);
  $userData = $user->checkUser($email, $pass);
  /* echo "<pre>";
  print_r($adminData);
  exit; */
  $data = array(
    "email" => $email,
    "pass" => $pass
  );
  if (($adminData->email == $email) && ($adminData->password == $pass)) {
    session_id("umdSessionAdmin");
    session_start();
    $_SESSION['session_admin'] = session_id();
    $_SESSION['admin_name'] = $adminData->name;
    $_SESSION['admin_email'] = $adminData->email;
    $admin->checkAdmin($data);
  } elseif ($userData->role_id == 1) {
    session_id("umdSessionNGOOwner");
    session_start();
    $_SESSION['session_ngo_owner'] = session_id();
    $_SESSION['ngo_owner_id'] = $userData->id;
    $_SESSION['ngo_owner_name'] = $userData->fullname;
    $_SESSION['ngo_owner_email'] = $userData->email;
    $_SESSION['ngo_owner_image'] = $userData->image;
    $user->check_ngo_owner($data);
  } elseif ($userData->role_id == 2) {
    session_id("umdSessionDonor");
    session_start();
    $_SESSION['session_donor'] = session_id();
    $_SESSION['donor_id'] = $userData->id;
    $_SESSION['donor_name'] = $userData->fullname;
    $_SESSION['donor_email'] = $userData->email;
    $_SESSION['donor_image'] = $userData->image;
    $user->check_donor($data);
  } else {
    echo "<script>alert('Something Went Wrong')</script>";
    echo "<script>window.history.back()</script>";
    /* 
      ? This is for NGO and Donor Login Credentials
    */
  }
}
