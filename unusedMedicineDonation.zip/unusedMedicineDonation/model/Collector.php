<?php
require_once "../include/Database.php";
class Collector
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }

  /*
  ! Function used to add collector data 
  */
  function add_collector($data)
  {
    $this->con->query("INSERT INTO collector VALUES(NULL, :name, :age, :email, :pass, :add1, :add2, :city, :mobile, :adhar, :image, :user_id, NOW(), NOW(), 1)");
    $this->con->bind(":name", $data['name']);
    $this->con->bind(":age", $data['age']);
    $this->con->bind(":email", $data['email']);
    $this->con->bind(":pass", $data['pass']);
    $this->con->bind(":add1", $data['add1']);
    $this->con->bind(":add2", $data['add2']);
    $this->con->bind(":city", $data['city']);
    $this->con->bind(":mobile", $data['mobile']);
    $this->con->bind(":adhar", $data['adhar']);
    $this->con->bind(":image", $data['image']);
    $this->con->bind(":user_id", $data['user_id']);
    if ($this->con->execute()) {
      echo "<script>alert('Collector Added Successfully..!')</script>";
      echo "<script>window.location.href='../ngo/manage_collectors.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>winodow.history.back()</script>";
    }
  }

  /* 
    ! Function used to Read all collector data
  */
  function fetch_collector_all_data($user_id)
  {
    $this->con->query("SELECT * FROM collector WHERE user_id = $user_id AND deleted_at = 1");
    return $this->con->resultSet();
  }

  /* 
    ! Function used to Read particular collectors data
  */
  function fetch_collector_single_data($collector_id)
  {
    $this->con->query("SELECT * FROM collector WHERE id = $collector_id AND deleted_at = 1");
    return $this->con->single();
  }

  /* 
  ! Function used to update collector's Data
  */
  function update_collector($data)
  {
    $this->con->query("UPDATE collector SET mrName = :name, mrAge = :age, mrEmail = :email, mrAddress1 =:add1, mrAddress2 = :add2, mrCity = :city, mrMobile = :mobile, mrAdhar = :adhar, modified_at = NOW() WHERE id = :collector_id");
    $this->con->bind(":name", $data['name']);
    $this->con->bind(":age", $data['age']);
    $this->con->bind(":email", $data['email']);
    $this->con->bind(":add1", $data['add1']);
    $this->con->bind(":add2", $data['add2']);
    $this->con->bind(":city", $data['city']);
    $this->con->bind(":mobile", $data['mobile']);
    $this->con->bind(":adhar", $data['adhar']);
    $this->con->bind(":collector_id", $data['collector_id']);
    if ($this->con->execute()) {
      echo "<script>alert('Collector Updated Successfully..!')</script>";
      echo "<script>window.location.href='../ngo/manage_collectors.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>winodow.history.back()</script>";
    }
  }
  /* 
    ! Function used to delete collectors
  */
  function delete_collector($collector_id)
  {
    $this->con->query("UPDATE collector SET deleted_at=0 WHERE id=$collector_id");
    if ($this->con->execute()) {
      echo "<script>alert('Collector Successfully Deleted...')</script>";
      echo "<script>window.location.href='../ngo/manage_collectors.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
  /* 
    ! Function used to Update Donation status into assigned ie 4
  */
  function assigned_value($donate_id)
  {

    $this->con->query("UPDATE donations SET status = 4, modified_at = NOW() WHERE id = $donate_id AND deleted_at = 1");
    return $this->con->execute();
  }
  /* 
    ! Function used to add assign accept request to collector
  */
  function create_assign($data)
  {
    $this->assigned_value($data['donate_id']);

    $this->con->query("INSERT INTO assign VALUES(NULL, :assign_by, :assign_to, :collect_from, :assign_date, NOW(), NOW(), 1)");
    $this->con->bind(":assign_by", $data['assign_by']);
    $this->con->bind(":assign_to", $data['assign_to']);
    $this->con->bind(":collect_from", $data['collect_from']);
    $this->con->bind(":assign_date", $data['assign_date']);
    if ($this->con->execute()) {
      echo "<script>alert('Assigned date to collector to colect medicines..!')</script>";
      echo "<script>window.location.href='../ngo/manage_donations.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>winodow.history.back()</script>";
    }
  }
  /* 
    ! Follwing Function used to display total Collector
  */
  function get_total_collector($user_id)
  {
    $this->con->query("SELECT * FROM collector WHERE deleted_at = 1 AND user_id = $user_id");
    return $this->con->rowCount();
  }

  /* 
    ! Function used to 
  */
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
