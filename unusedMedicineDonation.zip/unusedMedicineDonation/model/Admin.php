<?php
require_once "../include/Database.php";
class Admin
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }

  function singleData($id)
  {
    $this->con->query("SELECT * FROM admin WHERE id=:id");
    $this->con->bind(':id', $id);
    return $this->con->single();
  }

  function checkAdmin($data)
  {
    $this->con->query("SELECT * FROM admin WHERE email=:email AND password=:pass");
    $this->con->bind(':email', $data['email']);
    $this->con->bind(':pass', $data['pass']);
    $this->con->execute();
    $rows = $this->con->rowCount();
    if ($rows == 1) {
      echo "<script>alert('Admin Login Successfully')</script>";
      echo "<script>window.location.href='../admin/dashboard.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

  /* 
    ? Below Functions are using for block and unclock NGO users from Admin side...
  */
  function status_block_ngo_user($ngo_user_id)
  {
    $this->con->query("UPDATE users SET deleted_at = 0 WHERE id=:ngo_user_id");
    $this->con->bind(':ngo_user_id', $ngo_user_id);
    if ($this->con->execute()) {
      echo "<script>alert('User Block Successfully')</script>";
      echo "<script>window.location.href='../admin/manage_ngo_owner.php'</script>";
    } else {
      echo "<script>alert('Something went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
  function status_unblock_ngo_user($ngo_user_id)
  {
    $this->con->query("UPDATE users SET deleted_at = 1 WHERE id=:ngo_user_id");
    $this->con->bind(':ngo_user_id', $ngo_user_id);
    if ($this->con->execute()) {
      echo "<script>alert('User Unblock Successfully')</script>";
      echo "<script>window.location.href='../admin/manage_ngo_owner.php'</script>";
    } else {
      echo "<script>alert('Something went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

  /* 
    ? Below Functions are using for block and unclock NGO users from Admin side...
  */
  function status_block_donor_user($donor_user_id)
  {
    $this->con->query("UPDATE users SET deleted_at = 0 WHERE id=:donor_user_id");
    $this->con->bind(':donor_user_id', $donor_user_id);
    if ($this->con->execute()) {
      echo "<script>alert('User Block Successfully')</script>";
      echo "<script>window.location.href='../admin/manage_donor.php'</script>";
    } else {
      echo "<script>alert('Something went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
  function status_unblock_donor_user($donor_user_id)
  {
    $this->con->query("UPDATE users SET deleted_at = 1 WHERE id=:donor_user_id");
    $this->con->bind(':donor_user_id', $donor_user_id);
    if ($this->con->execute()) {
      echo "<script>alert('User Unblock Successfully')</script>";
      echo "<script>window.location.href='../admin/manage_donor.php'</script>";
    } else {
      echo "<script>alert('Something went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

  /* 
    ! Following Functions used to Count of total ngo, collectors, requsts accepted
    ! request decline, request pending, total medicine covers, and many more
  */
  function total_count($tables)
  {
    $this->con->query("SELECT * FROM $tables WHERE deleted_at = 1");
    return $this->con->rowCount();
  }

  function total_request($table, $status)
  {
    $this->con->query("SELECT * FROM $table WHERE status = $status AND deleted_at = 1");
    return $this->con->rowCount();
  }

  function total_medicine($table, $status)
  {
    $this->con->query("SELECT * FROM $table WHERE status != $status AND deleted_at = 1");
    return $this->con->rowCount();
  }
  /* 
    ! Following function used to display NGO and Owner name, Collectors List, Accepted List, Declined List, Assigned List, Pending List
  */
  function ngo_list()
  {
    $this->con->query(
      "SELECT * FROM users as u
      INNER JOIN ngo as n
      ON n.user_id = u.id
      WHERE n.deleted_at = 1 AND u.deleted_at = 1"
    );
    return $this->con->resultSet();
  }

  function collector_list()
  {
    $this->con->query("SELECT * FROM collector WHERE deleted_at=1");
    return $this->con->resultSet();
  }

  function donation_list($status)
  {
    $this->con->query(
      "SELECT * FROM ngo AS n
      INNER JOIN users AS u
      INNER JOIN donations AS d
      ON d.ngo_id = n.id AND d.user_id = u.id
      WHERE d.status = $status AND d.deleted_at = 1 AND u.deleted_at = 1 AND n.deleted_at = 1"
    );
    return $this->con->resultSet();
  }

  function medicine_details()
  {
    $this->con->query("SELECT * FROM donations WHERE deleted_at=1");
    return $this->con->resultSet();
  }
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
