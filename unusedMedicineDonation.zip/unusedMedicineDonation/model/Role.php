<?php
require_once "include/Database.php";
class Role
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }

  /* 
    * Function used to display all roles
  */
  function fetchAllData()
  {
    $this->con->query("SELECT * FROM role");
    return $this->con->resultSet();
  }
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
