<?php
require_once "../include/Database.php";
class Ngo
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }

  /* Function used to add ngo in list */
  function add_data($data)
  {
    $this->con->query("INSERT INTO ngo VALUES(NULL, :ngo_name, :add1, :add2, :city, :mobile, :website, :user_id, NOW(), NOW(), 1)");
    $this->con->bind(':ngo_name', $data['ngo_name']);
    $this->con->bind(':add1', $data['add1']);
    $this->con->bind(':add2', $data['add2']);
    $this->con->bind(':city', $data['city']);
    $this->con->bind(':mobile', $data['mobile']);
    $this->con->bind(':website', $data['website']);
    $this->con->bind(':user_id', $data['user_id']);
    if ($this->con->execute()) {
      echo "<script>alert('Data Inserted Successfully')</script>";
      echo "<script>window.location.href='../ngo/create_ngo.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

  /* Fetch all data from NGO table for particular user session */
  function fetch_ngo_all_data($sessId)
  {
    $this->con->query("SELECT * FROM ngo WHERE user_id=$sessId AND deleted_at=1");
    return $this->con->resultSet();
  }

  /* Fetc single row from ngo table from given id */
  function fetch_ngo_data($ngo_id)
  {
    $this->con->query("SELECT * FROM ngo WHERE id=$ngo_id AND deleted_at=1");
    return $this->con->single();
  }

  /* Function use to add NGO Details */
  function add_ngo_details($data)
  {
    $this->con->query("INSERT INTO ngo_desc VALUES(NULL, :ngo_id, :branch, :members, :description, :awards, :awardImage, :achievement, :successStory, :sstImage, NOW(), NOW(), 1)");
    $this->con->bind(":ngo_id", $data['ngo_id']);
    $this->con->bind(":branch", $data['branch']);
    $this->con->bind(":members", $data['members']);
    $this->con->bind(":description", $data['description']);
    $this->con->bind(":awards", $data['awards']);
    $this->con->bind(":awardImage", $data['awardImage']);
    $this->con->bind(":achievement", $data['achievement']);
    $this->con->bind(":successStory", $data['successStory']);
    $this->con->bind(":sstImage", $data['sstImage']);
    if ($this->con->execute()) {
      echo "<script>alert(Record Uploaded...!)</script>";
      echo "<script>window.location.href='../ngo/manage_ngo.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>window.history.back()'</script>";
    }
  }

  /* Funtion use to display complete ngo Details from ngo and description table */
  function fetch_ngo_details($ngo_id, $sessId)
  {
    $this->con->query(
      "SELECT * FROM ngo as n
      INNER JOIN ngo_desc as d
      ON n.id = d.ngo_id
      WHERE n.id=$ngo_id AND n.user_id=$sessId AND n.deleted_at=1 AND d.deleted_at=1"
    );
    return $this->con->single();
  }




  /* 
    ! Follwing Function used to display total NGO
  */
  function get_total_ngo($user_id)
  {
    $this->con->query("SELECT * FROM ngo WHERE deleted_at = 1 AND user_id = $user_id");
    return $this->con->rowCount();
  }

  /* 
    ! Fiunction used to get ngo owner and donor name
  */
  function get_users_info($donate_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN users as u
      ON d.user_id = u.id
      WHERE d.id = $donate_id"
    );
    return $this->con->single();
  }
  /* 
    todo Following functions used for donors
  */

  /* 
    ! Function use to get Total NGO for Donors
  */
  function get_ngo_count()
  {
    $this->con->query("SELECT * FROM ngo WHERE deleted_at=1");
    return $this->con->rowCount();
  }

  /* 
    ! Function use to display all ngo for Donors
  */
  function read_ngo()
  {
    $this->con->query("SELECT * FROM ngo WHERE deleted_at=1");
    return $this->con->resultSet();
  }

  /* 
    ! Function used to read only single row of NGO for donors
  */
  function read_single_ngo($ngo_id)
  {
    $this->con->query("SELECT * FROM ngo WHERE id=$ngo_id AND deleted_at=1");
    return $this->con->single();
  }
  /* 
    ! Function used to count total Medicine which is not assigned yet
  */
  function total_medicine($status, $user_id)
  {
    $this->con->query(
      "SELECT * FROM ngo AS n
      INNER JOIN donations AS d
      ON d.ngo_id = n.id
       WHERE d.status != $status AND n.user_id = $user_id AND d.deleted_at = 1 AND n.deleted_at = 1"
    );
    return $this->con->rowCount();
  }
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
