<?php
require_once "../include/Database.php";
class Donor
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }
  /* 
    ! Function use to add donation  into donation table
  */
  function add_donation($data)
  {
    $this->con->query("INSERT INTO donations VALUES(NULL, :ngo_id, :brand, :name, :type, :mfg_date, :exp_date, :med_image, :exp_image, :user_id, 1, NOW(), NOW(), 1)");
    $this->con->bind(":ngo_id", $data['ngo_id']);
    $this->con->bind(":brand", $data['brand']);
    $this->con->bind(":name", $data['name']);
    $this->con->bind(":type", $data['type']);
    $this->con->bind(":mfg_date", $data['mfg_date']);
    $this->con->bind(":exp_date", $data['exp_date']);
    $this->con->bind(":med_image", $data['med_image']);
    $this->con->bind(":exp_image", $data['exp_image']);
    $this->con->bind(":user_id", $data['user_id']);
    if ($this->con->execute()) {
      echo "<script>alert('Medicine Donated, now waiting for acceptance...!')</script>";
      echo "<script>window.location.href='../donor/manage_ngo.php'</script>";
    } else {
      echo "<script>alert('something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

  /* 
    ! Function used to Read donation List
  */
  function read_donations($user_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN ngo as n
      ON d.ngo_id = n.id
      WHERE d.user_id=$user_id AND d.deleted_at=1"
    );
    return $this->con->resultSet();
  }

  /* 
    ! Function used to read accepted donation request
  */
  function get_accepted_request($user_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN ngo as n
      ON d.ngo_id = n.id
      WHERE d.user_id=$user_id AND d.status = 2 AND d.deleted_at=1"
    );
    return $this->con->resultSet();
  }

  /* 
    ! Function used to read Declined donation request
  */
  function get_declined_request($user_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN ngo as n
      ON d.ngo_id = n.id
      WHERE d.user_id=$user_id AND d.status = 0 AND d.deleted_at=1"
    );
    return $this->con->resultSet();
  }
  /* 
    ! Function used to read Assigned donation request
  */
  function get_assigned_request($user_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN ngo as n
      ON d.ngo_id = n.id
      WHERE d.user_id=$user_id AND d.status = 4 AND d.deleted_at=1"
    );
    return $this->con->resultSet();
  }
  /* 
    ! Function used to read Assigned donation request
  */
  function get_pending_request($user_id)
  {
    $this->con->query(
      "SELECT * FROM donations as d
      INNER JOIN ngo as n
      ON d.ngo_id = n.id
      WHERE d.user_id=$user_id AND d.status = 1 AND d.deleted_at=1"
    );
    return $this->con->resultSet();
  }





  /* 
    ! Function used to count total rows of donated medicines
  */
  function get_donation_count($user_id)
  {
    $this->con->query("SELECT * FROM donations WHERE user_id = $user_id AND deleted_at=1");
    return $this->con->rowCount();
  }

  /* 
    ! Function used to count total rows of ACCEPTED Donations
  */
  function get_donation_accepted_count($user_id)
  {
    $this->con->query("SELECT * FROM donations WHERE user_id = $user_id AND status = 2 AND deleted_at=1");
    return $this->con->rowCount();
  }
  /* 
    ! Function used to count total rows of DECLINED Donations
  */
  function get_donation_decline_count($user_id)
  {
    $this->con->query("SELECT * FROM donations WHERE user_id = $user_id AND status = 0 AND deleted_at=1");
    return $this->con->rowCount();
  }
  /* 
    todo Following function used for NGOs
  */
  /* 
    ! Function used to Read Donation list
  */
  function read_ngo_donations($user_id)
  {
    $this->con->query(
      "SELECT * FROM users as u
      INNER JOIN ngo as n
      INNER JOIN donations as d
      ON d.ngo_id = n.id AND d.user_id = u.id
      WHERE n.user_id=$user_id AND d.deleted_at=1 AND n.deleted_at=1"
    );
    return $this->con->resultSet();
  }
  /* 
    ! Function used to Accept Medicine Request
  */
  function accept_request($donate_id)
  {
    $this->con->query("UPDATE donations SET status = 2, modified_at = NOW() WHERE id = $donate_id");
    if ($this->con->execute()) {
      echo "<script>alert('Request Accepted...!')</script>";
      echo "<script>window.location.href='../ngo/manage_donations.php'</script>";
    }
  }
  /* 
    ! Function used to Decline Medicine Request
  */
  function decline_request($donate_id)
  {
    $this->con->query("UPDATE donations SET status = 0, modified_at = NOW() WHERE id = $donate_id");
    if ($this->con->execute()) {
      echo "<script>alert('Request Declined...!')</script>";
      echo "<script>window.location.href='../ngo/manage_donations.php'</script>";
    }
  }
  /* 
    ! Function use to Read Donor List for NGO
  */
  function read_donors()
  {
    $this->con->query("SELECT * FROM users WHERE role_id=2 AND deleted_at=1");
    return $this->con->resultSet();
  }
  /* 
    ! Function use to Count total rows of Donors for NGO
  */
  function get_donors()
  {
    $this->con->query("SELECT * FROM users WHERE role_id = 2 AND deleted_at=1");
    return $this->con->rowCount();
  }
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
