<?php
require_once "../include/Database.php";
class Register
{
  private $con;
  function __construct()
  {
    $this->con = new Database();
    if (!$this->con->isConnected()) {
      echo $this->con->getError();
    }
  }


  /* 
    * Below functions are using for showing row data of particular email and password
  */
  function checkUser($email, $pass)
  {
    $this->con->query("SELECT * FROM users WHERE email=:email AND password=:pass AND deleted_at=1");
    $this->con->bind(':email', $email);
    $this->con->bind(':pass', $pass);
    return $this->con->single();
  }


  /* Function use to give login access to NGO owner*/
  function check_ngo_owner($data)
  {
    $this->con->query("SELECT * FROM users WHERE email=:email AND password=:pass AND deleted_at=1");
    $this->con->bind(':email', $data['email']);
    $this->con->bind(':pass', $data['pass']);
    $this->con->execute();
    $rows = $this->con->rowCount();
    if ($rows == 1) {
      echo "<script>alert('NGO Owner Login Successfully')</script>";
      echo "<script>window.location.href='../ngo/dashboard.php'</script>";
    } else {
      echo "<script>alert('You have bolocked by Admin side')</script>";
      echo "<script>window.history.back()</script>";
    }
  }


  /* Function use to give login access to Donor*/
  function check_donor($data)
  {
    $this->con->query("SELECT * FROM users WHERE email=:email AND password=:pass AND deleted_at=1");
    $this->con->bind(':email', $data['email']);
    $this->con->bind(':pass', $data['pass']);
    $this->con->execute();
    $rows = $this->con->rowCount();
    if ($rows == 1) {
      echo "<script>alert('Donor Login Successfully')</script>";
      echo "<script>window.location.href='../donor/dashboard.php'</script>";
    } else {
      echo "<script>alert('You have bolocked by Admin side')</script>";
      echo "<script>window.history.back()</script>";
    }
  }


  /* Function use to register users data*/
  function addData($data)
  {
    $this->con->query("INSERT INTO users VALUES(NULL, :name, :age, :email, :pass, :add1, :add2, :city, :mobile, :adhar, :image, :role_id, NOW(), NOW(), 1)");
    $this->con->bind(':name', $data['name']);
    $this->con->bind(':age', $data['age']);
    $this->con->bind(':email', $data['email']);
    $this->con->bind(':pass', $data['pass']);
    $this->con->bind(':add1', $data['add1']);
    $this->con->bind(':add2', $data['add2']);
    $this->con->bind(':city', $data['city']);
    $this->con->bind(':mobile', $data['mobile']);
    $this->con->bind(':adhar', $data['adhar']);
    $this->con->bind(':image', $data['image']);
    $this->con->bind(':role_id', $data['role_id']);
    if ($this->con->execute()) {
      echo "<script>alert('Register Successfully')</script>";
      echo "<script>window.location.href='../index.php'</script>";
    } else {
      echo "<script>alert('Something Went Wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }


  /* Function used to display NGO users list */
  function fetch_ngo_user_all_data()
  {
    $this->con->query("SELECT * FROM users WHERE role_id = 1");/* role_id = 1 = NGO */
    return $this->con->resultSet();
  }

  /* Function used to display Donor users list */
  function fetch_donor_all_data()
  {
    $this->con->query("SELECT * FROM users WHERE role_id = 2");/* role_id = 2 = Donor */
    return $this->con->resultSet();
  }

  /* Function used to count user list */
  function count_users()
  {
    $this->con->query("SELECT * FROM users");
    return $this->con->rowCount();
  }
  /*
    * Function use to display object
    * wheather it is created or not
  */
  function __toString()
  {
    $msg = "Hello From Object";
    return $msg;
  }
}
