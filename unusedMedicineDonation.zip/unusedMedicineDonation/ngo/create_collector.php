<?php
require_once "session.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | NGO</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Create Collectors</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Add Collector</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-md-8 offset-md-2">
              <div class="card elevation-3 card-success">
                <div class="card-header">
                  <h1 class="card-title">Add Collector</h1>
                </div>
                <form action="../controller/CollectorController.php" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="form-group mb-3">
                      <label for="FullName">Full Name</label>
                      <input type="text" name="name" id="FullName" class="form-control" placeholder="Full name">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Age">Age</label>
                      <input type="text" name="age" id="Age" class="form-control" placeholder="Age">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Email">Email</label>
                      <input type="email" id="Email" name="email" class="form-control" placeholder="Email">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Password">Password</label>
                      <input type="password" id="Password" name="pass" class="form-control" placeholder="Password">
                    </div>
                    <div class="form-group mb-3">
                      <label for="ConfirmPassword">ConfirmPassword</label>
                      <input type="password" name="cpass" id="ConfirmPassword" class="form-control" placeholder="Retype password">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Address1">Address1</label>
                      <input type="text" name="add1" id="Address1" class="form-control" placeholder="Plot No, Street Name">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Address2">Address2</label>
                      <input type="text" name="add2" id="Address2" class="form-control" placeholder="Landmark, Road">
                    </div>
                    <div class="form-group mb-3">
                      <label for="City">City</label>
                      <input type="text" name="city" id="City" class="form-control" placeholder="City">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Mobile">Mobile</label>
                      <input type="text" name="mobile" id="Mobile" class="form-control" placeholder="Mobile Number" maxlength="10">
                    </div>
                    <div class="form-group mb-3">
                      <label for="Adhar">Adhar</label>
                      <input type="text" name="adhar" id="Adhar" class="form-control" placeholder="Adhar Card number" maxlength="12">
                    </div>
                    <div class="form-group mb-3 row">
                      <label for="ProfilePicture" class="col-sm-4">Profile Picture</label>
                      <input type="file" name="image" id="ProfilePicture" class="form-control-file col-sm-8" accept=".jpg,.png">
                    </div>

                    <div class="form-group">
                      <!-- <label for="Owner_Name">Owner Name <sup class="text-danger">*</sup></label> -->
                      <input type="hidden" name="user_id" value="<?php echo $_SESSION['ngo_owner_id'] ?>">

                    </div>
                  </div>
                  <div class="card-footer">
                    <input type="submit" name="collector_submit" class="btn btn-success" value="Register">
                    <input type="reset" class="btn btn-danger" value="Cancel">
                  </div>
                </form>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
</body>

</html>