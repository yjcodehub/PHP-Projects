<?php
require_once "session.php";
require_once "../model/Ngo.php";
$ngo_id = intval($_GET['ngo_id']);
$ngo = new Ngo();

$data = $ngo->fetch_ngo_data($ngo_id); //Function use for fetching particular id data....
/* echo "<pre>";
print_r($data);
 */
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | NGO</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Details of NGO</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item"><a href="manage_ngo.php">Manage NGO</a></li>
                <li class="breadcrumb-item active">Add NGO Details</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-md-8 offset-md-2">
              <div class="card elevation-3 card-success">
                <div class="card-header">
                  <h1 class="card-title">Add NGO Details</h1>
                </div>
                <form action="../controller/NgoController.php" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="form-group">
                      <label for="NGOname">Name of NGO <sup class="text-danger">*</sup></label>
                      <input type="hidden" name="ngo_id" value="<?php echo $data->id ?>">
                      <input type="text" id="NGOname" class="form-control" value="<?php echo $data->ngoName ?>" readonly>
                    </div>
                    <div class="form-group">
                      <label for="Branch">Any Branch</label>
                      <input type="text" name="branch" id="Branch" class="form-control" placeholder="Branch Name">
                      <small class="text-muted">Mention address</small>
                    </div>
                    <div class="form-group">
                      <label for="Members">Members</label>
                      <input type="text" name="members" id="Members" class="form-control" placeholder="Total Members">
                    </div>
                    <div class="form-group">
                      <label for="Description">Description</label>
                      <textarea name="description" id="Description" class="form-control" placeholder="Since, Information and many more"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="Awards">Awards</label>
                      <textarea name="awards" id="Awards" class="form-control" placeholder="1. 1st in  xyz event. &#10;2. 2nd in abc event"></textarea>
                      <small class="text-muted">Mention point wise</small>
                    </div>
                    <div class="form-group">
                      <label for="Awards_Images">Awards Images</label>
                      <input type="file" name="awardImage" id="Awards_Images" class="form-control-file">
                    </div>
                    <div class=" form-group">
                      <label for="Achievements">Achievements</label>
                      <textarea name="achievement" id="Achievements" class="form-control" placeholder="1. Donate 500 cloths &#10;2. Donate 200 cycles. and many more like this"></textarea>
                      <small class="text-muted">Mention point wise</small>
                    </div>
                    <div class=" form-group">
                      <label for="Success_story">Success story</label>
                      <textarea name="successStory" id="Success_story" class="form-control" placeholder="Success Story Information"></textarea>
                    </div>
                    <div class="form-group">
                      <label for="SuccessStoryImage">Success Story Image</label>
                      <input type="file" name="sstImage" id="SuccessStoryImage" class="form-control-file">
                    </div>
                  </div>
                  <div class="card-footer">
                    <input type="submit" name="ngo_detail_submit" class="btn btn-success" value="ADD">
                    <input type="reset" class="btn btn-danger" value="Cancel">
                  </div>
                </form>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
</body>

</html>