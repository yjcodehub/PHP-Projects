<?php
error_reporting(0);
session_id("umdSessionNGOOwner");
session_start();
$id = session_id();
if ($id != $_SESSION['session_ngo_owner']) {
  session_destroy();
  echo "<script>alert('Please login first')</script>";
  echo "<script>window.location.href='../index.php'</script>";
}
