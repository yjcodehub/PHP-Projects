<?php
require_once "session.php";
require_once "../model/Collector.php";
$collector = new Collector();
$data = $collector->fetch_collector_single_data($_GET['collector_id']); //Function used particular collector data
/* echo "<pre>";
print_r($data);
exit; */
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | NGO</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">View Collector</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item"><a href="create_collector.php">Add Collector</a></li>
                <li class="breadcrumb-item"><a href="manage_collectors.php">Manage Collector</a></li>
                <li class="breadcrumb-item active">View Collector</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row justify-content-center">
            <div class="col-12 col-md-4">
              <div class="card card-success">
                <div class="card-header">
                  <h3 class="card-title">View Collector</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <img src="../public/_uploads/<?php echo $data->mrImage ?>" alt="collector Image" class="rounded-circle img-thumbnail d-block mx-auto" width="100" height="100">
                  <div class="w-100 my-3">
                    <strong><i class="fas fa-user mr-2"></i> Full Name</strong>
                    <p class="mt-2">
                      <?php echo $data->mrName ?>
                    </p>
                  </div>
                  <hr>
                  <div class="w-100 my-3">
                    <strong><i class="fas fa-calendar-day mr-2"></i> Age</strong>
                    <p class="mt-2">
                      <?php echo $data->mrAge ?>
                    </p>
                  </div>
                  <hr>
                  <div class="w-100 my-3">
                    <strong><i class="fas fa-envelope mr-2"></i> Email</strong>
                    <p class="mt-2">
                      <?php echo $data->mrEmail ?>
                    </p>
                  </div>
                  <hr>
                  <div class="w-100 my-3">
                    <strong><i class="fas fa-phone mr-2"></i> Mobile</strong>
                    <p class="mt-2">
                      <?php echo $data->mrMobile ?>
                    </p>
                  </div>
                  <hr>
                  <div class="w-100 my-3">
                    <strong><i class="fas fa-map-marked-alt mr-2"></i> Address</strong>
                    <p class="mt-2">
                      <?php echo "$data->mrAddress1, $data->mrAddress2, $data->mrCity" ?>
                    </p>
                  </div>
                  <hr>
                  <div class="w-100 mt-3">
                    <strong><i class="fas fa-fingerprint mr-2"></i> Adhaar Card Number</strong>
                    <p class="mt-2">
                      <?php echo $data->mrAdhar ?>
                    </p>
                  </div>
                  <hr>
                </div>
                <!-- /.card-body -->
                <div class="card-footer text-center bg-white">
                  <a href="manage_collectors.php" class="btn bg-gradient-primary">BACK</a>
                </div>
              </div>
              <!-- /.card -->
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
  <!-- DataTables  & Plugins -->
  <script src="../public/dashboard/plugins/datatables/jquery.dataTables.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
  <script src="../public/dashboard/plugins/jszip/jszip.min.js"></script>
  <script src="../public/dashboard/plugins/pdfmake/pdfmake.min.js"></script>
  <script src="../public/dashboard/plugins/pdfmake/vfs_fonts.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.print.min.js"></script>
  <script src="../public/dashboard/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
  <!-- Page Script -->
  <script>
    $("#example1").DataTable({
      "responsive": true,
      "lengthChange": false,
      "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
  </script>
</body>

</html>