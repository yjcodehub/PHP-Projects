<?php
require_once "session.php";
require_once "../model/Ngo.php";
$ngo_id = intval($_GET['ngo_id']);
$ngo = new Ngo();

$data = $ngo->fetch_ngo_details($ngo_id, $_SESSION['ngo_owner_id']); //Function use for fetching particular id data....
/* echo "<pre>";
print_r($data);
exit; */
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | NGO</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">View Details of NGO</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item"><a href="manage_ngo.php">Manage NGO</a></li>
                <li class="breadcrumb-item active">View NGO Details</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-md-8 offset-md-2 text-right">
              <a href="manage_ngo.php" class="btn btn-primary mb-3">Back</a>
              <div class="accordion text-left" id="accordionExample">
                <div class="card">
                  <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        General Information
                      </button>
                    </h2>
                  </div>

                  <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Name</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->ngoName ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Address</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo "$data->ngoAddress1, $data->ngoAddress2, $data->ngoCity" ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Website</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->ngoWebsite ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Mbile Number</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->ngoMobile ?></h5>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="card-header" id="headingTwo">
                    <h2 class="mb-0">
                      <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                        Detailed Information
                      </button>
                    </h2>
                  </div>

                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Branch</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->branch ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Members</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->members ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Description</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->description ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Awards</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->award ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Award Images</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          : <img src="../public/_uploads/awards/<?php echo $data->awardImage ?>" alt="NGO AWARDS" class="img-fluid">
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Achievements</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->achievements ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Success Stories</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          <h5 class="card-title">: <?php echo $data->successStory ?></h5>
                        </div>
                        <div class="col-sm-3 mb-3">
                          <h6>NGO Success Story Images</h6>
                        </div>
                        <div class="col-sm-9 mb-3">
                          : <img src="../public/_uploads/success_story/<?php echo $data->successStoryImage ?>" alt="NGO SUCCESS STORIES" class="img-fluid">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>



  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
</body>

</html>