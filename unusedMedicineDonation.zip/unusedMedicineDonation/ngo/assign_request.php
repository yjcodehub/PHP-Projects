<?php
require_once "session.php";
require_once "../model/Collector.php";
require_once "../model/Ngo.php";
$collector = new Collector();
$ngo = new Ngo();
$data = $ngo->get_users_info($_GET['donate_id']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Unused Medicine Donation | NGO</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="../public/dashboard/plugins/fontawesome-free/css/all.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../public/dashboard/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="../public/dashboard/plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="../public/dashboard/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../public/dashboard/dist/css/adminlte.min.css">
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
  <div class="wrapper">

    <!-- Preloader -->
    <div class="preloader flex-column justify-content-center align-items-center">
      <img class="animation__wobble" src="../public/_img/medicine.png" alt="medicine" height="60" width="60">
    </div>

    <!-- Navbar -->
    <?php
    require_once "../include/header.php";
    ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php
    require_once "../include/aside.php";
    ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Assign Collecting Request</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active">Assign Request</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-md-8 offset-md-2">
              <div class="card elevation-3 card-success">
                <div class="card-header">
                  <h1 class="card-title">Assign date to collect Medicines</h1>
                </div>
                <form action="../controller/CollectorController.php" method="post" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="form-group mb-3">
                      <label for="AssignBy">Assign By</label>
                      <input type="hidden" name="assign_by" value="<?php echo $_SESSION['ngo_owner_id'] ?>">
                      <input type="text" id="AssignBy" class="form-control" value="<?php echo $_SESSION['ngo_owner_name'] ?>" readonly>
                    </div>
                    <div class="form-group mb-3">
                      <label for="AssignTo">Assign To</label>
                      <select name="assign_to" id="AssignTo" class="form-control select2">
                        <?php
                        $datas = $collector->fetch_collector_all_data($_SESSION['ngo_owner_id']);
                        $count = 0;
                        foreach ($datas as $mrData) {
                          echo "<option value='$mrData->id'>$mrData->mrName</option>";
                        }
                        ?>

                      </select>
                      <small>Select one of your Collectors</small>
                    </div>
                    <div class="form-group mb-3">
                      <label for="CollectFrom">Collect From</label>
                      <input type="hidden" name="collect_from" value="<?php echo $data->user_id ?>">
                      <input type="text" id="CollectFrom" class="form-control" value="<?php echo $data->fullname ?>" readonly>
                    </div>
                    <div class="form-group mb-3">
                      <label for="AssignDate">Assign Date</label>
                      <input type="date" id="AssignDate" name="assign_date" class="form-control">
                      <small class="text-muted">Please select date after 2 days</small>
                    </div>
                    <input type="hidden" name="donate_id" value="<?php echo $_GET['donate_id'] ?>">
                  </div>
                  <div class="card-footer">
                    <input type="submit" name="assign_submit" class="btn btn-success" value="Assign">
                    <input type="reset" class="btn btn-danger" value="Cancel">
                    <a href="manage_donations.php" class="btn btn-primary float-right"> Back</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control sidebar and footer -->
    <?php
    require_once "../include/footer.php";
    ?>
    <!-- /.Control sidebar and footer -->
  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="../public/dashboard/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="../public/dashboard/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="../public/dashboard/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="../public/dashboard/dist/js/adminlte.js"></script>
  <!-- Select2 -->
  <script src="../public/dashboard/plugins/select2/js/select2.full.min.js"></script>


  <!-- AdminLTE for demo purposes -->
  <script src="../public/dashboard/dist/js/demo.js"></script>
  <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
  <script src="../public/dashboard/dist/js/pages/dashboard2.js"></script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $('.select2').select2()
    });
  </script>
</body>

</html>