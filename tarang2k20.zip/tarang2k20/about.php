<!DOCTYPE html>

<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>TARANG 2020</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="website/img/favicon.png">
    <!-- Place favicon.ico in the root directory -->

    <!-- CSS here -->
    <link rel="stylesheet" href="website/css/bootstrap.min.css">
    <link rel="stylesheet" href="website/css/owl.carousel.min.css">
    <link rel="stylesheet" href="website/css/magnific-popup.css">
    <link rel="stylesheet" href="website/css/font-awesome.min.css">
    <link rel="stylesheet" href="website/css/themify-icons.css">
    <link rel="stylesheet" href="website/css/gijgo.css">
    <link rel="stylesheet" href="website/css/nice-select.css">
    <link rel="stylesheet" href="website/css/animate.css">
    <link rel="stylesheet" href="website/css/flaticon.css">
    <link rel="stylesheet" href="website/css/slicknav.css">

    <link rel="stylesheet" href="website/css/style.css">
    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->

    <!-- header-start -->
    <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-3 col-lg-3">
                                <div class="logo">
                                    <a href="index.php">
                                        <h2>TARANG 2K20</h2>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-6">
                                <div class="main-menu  d-none d-lg-block">
                                    <nav class="text-right">
                                        <ul id="navigation">
                                            <li><a href="index.php">home</a></li>
                                            <li><a href="about.php" class="active">About</a></li>
                                            <li><a href="contact.php">Contact</a></li>
                                            <li><a href="event.php">Event</a></li>
                                            <li><a href="participant.php">Participants </a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->

    <!-- slider_area_start -->
    <div class="slider_area">
        <div class="single_slider  d-flex align-items-center slider_bg_1 overlay">
            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-xl-12">
                        <div class="slider_text text-center">
                            <div class="shape_1 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".2s">
                                <img src="website/img/shape/shape_1.svg" alt="">
                            </div>
                            <div class="shape_2 wow fadeInDown" data-wow-duration="1s" data-wow-delay=".2s">
                                <img src="website/img/shape/shape_2.svg" alt="">
                            </div>
                            <span class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".3s">27th & 28th Feb <br>TARANG 2020</span>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".4s">ABOUT</h3>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- slider_area_end -->


    <!-- about_area_start  -->
    <div class="about_area black_bg extra_padd">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section_title text-center mb-80">
                        <h3 class="wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s" >About PJLCE</h3>
                        <p class="wow fadeInRight" data-wow-duration="1s" data-wow-delay=".4s" >The event regularly attracts a diverse range of attendees from around the world, across different professions, and with different.</p>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <div class="about_thumb">
                        <div class="shap_3  wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".4s">
                            <img src="website/img/shape/shape_3.svg" alt="">
                        </div>
                        <div class="thumb_inner  wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
                            <img src="img/25.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="about_info pl-68">
                        <h4 class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">About PJLCE | The Environment</h4>
                        <hr color="green" class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">
                        <p  class=" wow fadeInLeft text-justify" data-wow-duration="1s" data-wow-delay=".6s">PJLCE is centrally located in the city of Nagpur, better known as Orange City'. It is a good combination of Cosmopolitanism and Tradition and is away from the rush and cut - throat competition of other big cities. It is destined to become the destination for an intentional industrial and trade centre with the MIHAN project which is spread over a vast area promising technological advancement. Despite hectic industrial activity, Nagpur remains the cleanest and second greenest city in the country. It offers excellent academic and industrial exposure to engineering students.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="about_info pl-68">
                        <h4 class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">Vision</h4>
                        <hr color="green" class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">
                        <p class=" wow fadeInLeft text-justify" data-wow-duration="1s" data-wow-delay=".6s">To produce engineers who are socially responsible & professionally competent to face the global challenges ahead.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about_info pl-68">
                        <h4 class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">Quality Policy</h4>
                        <hr color="green" class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">
                        <p class=" wow fadeInLeft text-justify" data-wow-duration="1s" data-wow-delay=".6s">
                            We are committed to impart value-added education that would enable us to fulfill the ever increasing demands of the competitive and target-driven business environment.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                   <div class="about_info pl-68">
                        <h4 class=" wow fadeInLeft text-center" data-wow-duration="1s" data-wow-delay=".5s">Mission</h4>
                        <hr color="green" class=" wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".5s">
                        <p class=" wow fadeInLeft text-left" data-wow-duration="1s" data-wow-delay=".6s">
                           o To achieve academic excellence by imparting quality education with practical quality education with practical oriented approach to serve the industries. <br>
                            o To satisfy the expectation of contributors <br>
                            o To develop Engineering Professionals having ethical values, skills & competencies. <br>
                            o To fulfill the need of society & industries by promoting research culture. <br>
                            o To stimulate learning environment for strengthening the individual potential. <br>
                        </p>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- about_area_end  -->

    <!-- brand_area_start  -->
    <div class="brand_area black_bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title text-center mb-80">
                        <h4 class="wow fadeInRight" data-wow-duration="1s" data-wow-delay=".3s">Sponsor Logos</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="brand_wrap">
                        <div class="brand_active owl-carousel">
                            <div class="single_brand text-center">
                                <img src="website/img/brand/1.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/2.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/3.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/4.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/5.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/1.png" alt="">
                            </div>
                            <div class="single_brand text-center">
                                <img src="website/img/brand/2.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- brand_area_end  -->
    <!-- footer_start  -->
    <footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="footer_widget">
                            <div class="address_details text-center">
                                <h4 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">27th & 28th Feb, 2020</h4>
                                <h3 class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".4s">TARANG 2020</h3>
                              <p class="wow fadeInUp" data-wow-duration="1s" data-wow-delay=".5s">The events in our lives happen in a sequence in time, but in their significance to ourselves they find their own order: the continues thread of revelation.</p>
                                <a href="register.php" class="boxed-btn3 wow fadeInUp" data-wow-duration="1s" data-wow-delay=".6s">Register for Event</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center wow fadeInDown" data-wow-duration="1s" data-wow-delay=".5s">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;2020 All rights reserved | This template is made <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://www.facebook.com/yash.jais.37" target="_blank">Yash Jais</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer_end  -->

    <!-- JS here -->
    <script src="website/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="website/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="website/js/popper.min.js"></script>
    <script src="website/js/bootstrap.min.js"></script>
    <script src="website/js/owl.carousel.min.js"></script>
    <script src="website/js/isotope.pkgd.min.js"></script>
    <script src="website/js/ajax-form.js"></script>
    <script src="website/js/waypoints.min.js"></script>
    <script src="website/js/jquery.counterup.min.js"></script>
    <script src="website/js/imagesloaded.pkgd.min.js"></script>
    <script src="website/js/scrollIt.js"></script>
    <script src="website/js/jquery.scrollUp.min.js"></script>
    <script src="website/js/wow.min.js"></script>
    <script src="website/js/gijgo.min.js"></script>
    <script src="website/js/nice-select.min.js"></script>
    <script src="website/js/jquery.slicknav.min.js"></script>
    <script src="website/js/jquery.magnific-popup.min.js"></script>
    <script src="website/js/tilt.jquery.js"></script>
    <script src="website/js/plugins.js"></script>



    <!--contact js-->
    <script src="website/js/contact.js"></script>
    <script src="website/js/jquery.ajaxchimp.min.js"></script>
    <script src="website/js/jquery.form.js"></script>
    <script src="website/js/jquery.validate.min.js"></script>
    <script src="website/js/mail-script.js"></script>


    <script src="website/js/main.js"></script>
</body>

</html>