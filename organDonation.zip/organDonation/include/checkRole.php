<?php
  /* 
    * Following two lines are executing the roles
    * to display the role on a left side of Header
  */
  $result = $con->query("SELECT * FROM users WHERE userId = $_SESSION[userId] AND deleted_at = 1");
  $dataRole = $result->fetch_object();
?>