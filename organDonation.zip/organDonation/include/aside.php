<?php
    if($_SESSION['sessId1']=="session1"){
        $bgcolor = "bg-gradient-primary";
    }elseif($_SESSION['sessId2']=="session2"){
        $bgcolor = "bg-gradient-danger";
    }else{
        $bgcolor = "bg-gradient-success";
    }

?>
<ul class="navbar-nav <?php echo $bgcolor?> sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-lungs"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Organ Donation</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Settings
    </div>

    <?php 
        if($_SESSION['sessId1']=="session1"){ /* Session 1 carries admin login */
    ?>
   
    <li class="nav-item">
        <a class="nav-link" href="manageReceptionist.php">
            <i class="fas fa-user"></i>
            <span>Receptionist</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="manageDonor.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Donors</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="manageReceiver.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Receivers</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="donorList.php">
            <i class="fas fa-list"></i>
            <span>List of Donations</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="requestList.php">
            <i class="fas fa-list-alt"></i>
            <span>List of Request</span>
        </a>
    </li>
    <?php
        }
        elseif($_SESSION['sessId2']=="session2"){ /* Session 2 carries Receptionist Login */
    ?>
     <li class="nav-item">
        <a class="nav-link" href="manageDonor.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Donors</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="donorList.php">
            <i class="fas fa-list"></i>
            <span>Requested Donor List</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="manageReceiver.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Receivers</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="requestList.php">
            <i class="fas fa-list"></i>
            <span>Requested Receiver List</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="assignList.php">
            <i class="fas fa-clipboard-check"></i>
            <span>Assigned Organ List</span>
        </a>
    </li>
    <?php
        }elseif($_SESSION['sessId3']=="session3"){ /* Session 3 carries Donor's Login */
    ?>
    <li class="nav-item">
        <a class="nav-link" href="createDonation.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Donation to Receptionist</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="donationList.php">
            <i class="fas fa-list"></i>
            <span>List of Donations</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="pendingList.php">
            <i class="fas fa-hourglass-half"></i>
            <span>Pending Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="acceptList.php">
            <i class="fas fa-check-double"></i>
            <span>Accepted Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="declineList.php">
            <i class="fas fa-window-close"></i>
            <span>Decline Request</span>
        </a>
    </li>
    <?php 
        }elseif($_SESSION['sessId4']=="session4"){ /* Session 4 carries Receiver's Login */
    ?>
    <li class="nav-item">
        <a class="nav-link" href="requestReception.php">
            <i class="fas fa-hand-holding-medical"></i>
            <span>Request to Receptionist</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="requestList.php">
            <i class="fas fa-list"></i>
            <span>List of Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="assignedList.php">
            <i class="fas fa-clipboard-check"></i>
            <span>Assigned Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="pendingList.php">
            <i class="fas fa-hourglass-half"></i>
            <span>Pending Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="acceptList.php">
            <i class="fas fa-check-double"></i>
            <span>Accepted Request</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="declineList.php">
            <i class="fas fa-window-close"></i>
            <span>Decline Request</span>
        </a>
    </li>
    <?php 
        }
    ?>
    
    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>