<?php
  extract($_POST);//$_POST variable instace remove
  extract($_GET);
  extract($_FILES);
  /* Database Connectivity */
  $con = new mysqli('localhost','root','','test_organ');
?>