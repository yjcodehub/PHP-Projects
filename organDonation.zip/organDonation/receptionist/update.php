<?php
  require "session.php";
  require "../include/connection.php";
  if(isset($profileUpdate)){
    $query="UPDATE users SET userFname='$fname', userLname='$lname', userAge='$age', userEmail='$email', userAddress1='$add1', userAddress2='$add2',userCity='$city', userMobile='$mobile', userAdhar='$adhaar', modified_at=NOW() WHERE userId=$userId";
    if($con->query($query)){/*  */
      $result = $con->query("SELECT * FROM users WHERE userId = $userId");
      $data = $result->fetch_object();
      $_SESSION['userFname'] = $data->userFname;
      $_SESSION['userLname'] = $data->userLname;

      echo "<script>alert('Profile Record updated')</script>";
      echo "<script>window.location.href='profile.php'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
?>