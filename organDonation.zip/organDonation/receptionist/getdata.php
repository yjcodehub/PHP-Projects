<?php 
  require "session.php";
  require "../include/connection.php";
  if(isset($accept)){
    if($role == "donor"){
      $query = "UPDATE donors SET donorStatus = 2, modified_at=NOW() WHERE donorId = '$accept'";
      if($con->query($query)){
        echo "<script>alert('Request Accepted Successfully...')</script>";
        echo "<script>window.location.href='donorList.php'</script>";
      }
    }else{
      $query = "UPDATE receivers SET receiverStatus = 2, modified_at=NOW() WHERE receiverId = '$accept'";
      if($con->query($query)){
        echo "<script>alert('Request Accepted Successfully...')</script>";
        echo "<script>window.location.href='requestList.php'</script>";
      }
    }
    
  }elseif(isset($reject)){
    if($role == "donor"){
      $query = "UPDATE donors SET donorStatus = 0, modified_at=NOW() WHERE donorId = '$reject'";
      if($con->query($query)){
        echo "<script>alert('Rquest Declined Successfully...')</script>";
        echo "<script>window.location.href='donorList.php'</script>";
      }
    }else{
      $query = "UPDATE receivers SET receiverStatus = 0, modified_at=NOW() WHERE receiverId = '$reject'";
      if($con->query($query)){
        echo "<script>alert('Rquest Declined Successfully...')</script>";
        echo "<script>window.location.href='requestList.php'</script>";
      }
    }
  }elseif(isset($assignSubmit)){
    $deleted_at = 1;
    $query = "INSERT INTO assign VALUES(NULL,'$donor_id', '$receptionist_id', '$receiverId','$receiver_id', '$organ', '$assignDate', NOW(), NOW(), $deleted_at)";
    if($con->query($query)){
      $con->query("UPDATE receivers SET receiverStatus = 4, modified_at = NOW() WHERE receiverId='$receiverId'");
      echo "<script>alert('Organ Assigned Successfully')</script>";
      echo "<script>window.location.href='requestList.php'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()'</script>";
    }
  }
?>