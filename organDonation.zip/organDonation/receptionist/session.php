<?php
  session_id("session2");
  session_start();
  $id = session_id();
  if($id != $_SESSION['sessId2']){
    session_destroy();
    header('location:../index.php');
  }
?>