<?php
  error_reporting(0);
  require "../include/connection.php";
  if(isset($organSubmit)){
    $status = $deleted_at = 1;
    $query = "INSERT INTO donors VALUES(NULL, '$donor_id', '$receptionist_id', '$organ', '$bloodGroup', '$height', '$weight', '$status', NOW(), NOW(), '$deleted_at')";
    if($con->query($query)){
      echo "<script>alert('Organ Donated..')</script>";
      echo "<script>window.location.href='donationForm.php?userId=".$receptionist_id."'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

?>
