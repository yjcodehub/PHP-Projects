<?php 
  require "session.php";
  require "../include/connection.php";
  if(isset($donorId)){
    $query = "UPDATE donors SET deleted_at=0, modified_at=NOW() WHERE donorId = $donorId";
    if($con->query($query)){
      echo "<script>alert('Organ Deleted...')</script>";
      echo "<script>window.location.href='donationList.php'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
?>