<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="public/css/style.css">

    <title>Login Page</title>
  </head>
  <body>
    <div class="container">
      <div class="row mt-5">
        <div class="col-md-8 mx-auto">
          <div class="card shadow-lg">
            <div class="card-body">
              <h2 class="card-title text-center text-primary">Organ Donate</h2>
              <form name="loginForm" method="post" action="check.php" onSubmit="return formValidate()">
                <div class="form-group">
                  <label for="inputEmail">Email address</label>
                  <input type="email" name="email" class="form-control" id="inputEmail">
                  <small class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                  <label for="inputPassword">Password</label>
                  <input type="password" name="password" class="form-control" id="inputPassword">
                </div>
                
                <button type="submit" class="btn btn-primary" name="userLogin">Login</button>
              </form>
              <p class="my-3 text-center">
                Don't have an account? <a href="register.php" class="text-primary">Please Sign up here!</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="public/js/jquery.slim.min.js"></script>
    <script src="public/js/bootstrap.bundle.min.js"></script>
    <!-- Validation Link -->
    <script src="public/js/validation/loginValidation.js"></script>
  </body>
</html>