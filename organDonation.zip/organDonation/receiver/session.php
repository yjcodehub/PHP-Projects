<?php
  session_id("session4");
  session_start();
  $id = session_id();
  if($id != $_SESSION['sessId4']){
    session_destroy();
    header('location:../index.php');
  }
?>