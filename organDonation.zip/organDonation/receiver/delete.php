<?php 
  require "session.php";
  require "../include/connection.php";
  if(isset($receiverId)){
    $query = "UPDATE receivers SET deleted_at=0, modified_at=NOW() WHERE receiverId = $receiverId";
    if($con->query($query)){
      echo "<script>alert('Organ Deleted...')</script>";
      echo "<script>window.location.href='requestList.php'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }
?>