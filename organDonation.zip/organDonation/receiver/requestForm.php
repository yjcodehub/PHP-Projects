<?php
  error_reporting(0);
  require "session.php";
  require "../include/connection.php";
  require "../include/checkRole.php";
  $result = $con->query("SELECT * FROM users WHERE userId = $userId AND deleted_at=1");
  $data = $result->fetch_object();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Yash Jais">

    <title>Organ Donation</title>

    <!-- Custom fonts for this template-->
    <link href="../public/dashboard/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../public/dashboard/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../public/dashboard/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php 
          require "../include/aside.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                  <?php
                    require "../include/header.php";
                  ?>        
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    
                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800 float-left">Organ Receive Form</h1>
                    <a href="requestReception.php" class="btn btn-primary float-right">Back</a>
                    <!-- Form Row -->
                    <div class="clearfix"></div>
                    <div class="row mt-4">
                      <div class="card shadow mb-4 col-sm-8 mx-auto p-0">
                        <div class="card-header">
                            <h6 class="m-0 font-weight-bold text-primary float-left mt-2">Fill The Form</h6>
                        </div>
                        <div class="card-body">
                          <form class="user" action="getdata.php" method="post">
                            <div class="form-row">
                              <label for="receiver" class="col-sm-4 h5">Request By,</label>
                              <div class="form-group col-sm-8">
                                <input type="hidden" name="receiver_id" value="<?php echo $_SESSION['userId']?>">
                                <input type="text" id="receiver" class="form-control form-control-user" value="<?php echo $_SESSION['userFname'].' '.$_SESSION['userLname']?>" readonly>
                              </div>

                              <label for="receptionist" class="col-sm-4 h5">Request to receptionist,</label>
                              <div class="form-group col-sm-8">
                                <input type="hidden" name="receptionist_id" value="<?php echo $data->userId?>">
                                <input type="text" id="receptionist" class="form-control form-control-user" value="<?php echo $data->userFname.' '.$data->userLname ?>" readonly>
                              </div>

                              <label for="organ" class="col-sm-4 h5">Organ to Request</label>
                              <div class="form-group col-sm-8">
                                <input type="text" name="organ" id="organ" class="form-control form-control-user" placeholder="Enter Organ">
                              </div>

                              <label for="bloodGroup" class="col-sm-4 h5">Blood Group</label>
                              <div class="form-group col-sm-8">
                                <input type="text" name="bloodGroup" id="bloodGroup" class="form-control form-control-user" placeholder="Enter Blood Group">
                              </div>

                              <label for="height" class="col-sm-4 h5">Height</label>
                              <div class="form-group col-sm-8">
                                <input type="text" name="height" id="height" class="form-control form-control-user" placeholder="Enter height">
                                <small class="text-muted">Please enter height in <b>"cm"</b> only</small>
                              </div>

                              <label for="weight" class="col-sm-4 h5">Weight</label>
                              <div class="form-group col-sm-8">
                                <input type="text" name="weight" id="weight" class="form-control form-control-user" placeholder="Enter weight">
                                <small class="text-muted">Please enter weight in <b>"kg"</b> only</small>
                              </div>
                            </div>
                            <button class="btn btn-success" type="submit" name="requestSubmit">Submit</button>
                            <button class="btn btn-danger" type="reset">Cancel</button>
                          </form>
                        </div>
                      </div>
                    </div>
                    <!-- /.Form -->
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php 
              require "../include/footer.php"
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../public/dashboard/vendor/jquery/jquery.min.js"></script>
    <script src="../public/dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../public/dashboard/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../public/dashboard/js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="../public/dashboard/vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../public/dashboard/js/demo/chart-area-demo.js"></script>
    <script src="../public/dashboard/js/demo/chart-pie-demo.js"></script>

       <!-- Page level plugins -->
    <script src="../public/dashboard/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="../public/dashboard/vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="../public/dashboard/js/demo/datatables-demo.js"></script>

    <!-- Validation Link -->


</body>

</html>