<?php
  error_reporting(0);
  require "../include/connection.php";
  if(isset($requestSubmit)){
    $status = $deleted_at = 1;
    $query = "INSERT INTO receivers VALUES(NULL, '$receiver_id', '$receptionist_id', '$organ', '$bloodGroup', '$height', '$weight', '$status', NOW(), NOW(), '$deleted_at')";
    if($con->query($query)){
      echo "<script>alert('Organ Requested..')</script>";
      echo "<script>window.location.href='requestReception.php?userId=".$receptionist_id."'</script>";
    }
    else{
      echo "<script>alert('Something went wrong')</script>";
      echo "<script>window.history.back()</script>";
    }
  }

?>
