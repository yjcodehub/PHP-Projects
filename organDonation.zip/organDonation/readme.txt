For access of this project please follow the following steps.

1. First you have to create database of name test_organ.
2. In public/database/test_organ.sql file import onto that database.
3. Confirm this as your organDonation project folder into xampp/htdocs folder if your are XAMPP user, wampp/www if your are WAMPP user
4. Then you have to access this project via localhost/organDonation in any browser URL
5. You will get Login page, you can register yourself as Donor and Receiver
6. If you want to access admin must type following credentials
	username:- admin@gmail.com
	password:- Admin@1234

7. You will redirected to Dashboard page of Admin


/+++++++
As name suggest that organDonation, The project is completely based on donation of organs to the needy one.
In today's, we all know about the situatuion so the organs have not got as fast as possible so this is a platform
where a needy one can request for organ and he will get response by his nearest hospital receptionist.
It will easy to find organs....

This project contains 4 modules
1. Admin
2. Receptionist
3. Donor
4. Receiver


Admin:- Admin can create receptionist data and manage
	Admin can see list of donors, receptionist, receivers

Receptionist:- 	Receptionist can see the list of Donors and Recievers
		Receptionist can accept and Decline the donate request from donors
		Receptionist can accept and Decline the receive request from receivers
		Receptionist can assign organs to Receiver if he has this organ

Donor:	Donor can register himself and login using his credentials
	Donor can donate organs to receptionist
	Donor can manage donated organs

Receiver: Receiver Can register himself and login using credentials
	  Receiver can request for organs to receptionist
	  Receiver can  manage the organ request section


++++++++/
