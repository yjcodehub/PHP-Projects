<?php   
  require "include/connection.php";
  if(isset($userLogin)){
   
    $password = md5($password);/* FUnction used fro Encryption */
    $query="SELECT * FROM users WHERE userEmail='$email' AND userPassword='$password' AND deleted_at=1";/* Check email and password from database */
    $result=$con->query($query); /* Function use fro Execute the Query */
  
    $data=$result->fetch_object();/* Function use for Data Fetching */
    /*echo "<pre>";
    print_r($data); */
    $rows = mysqli_num_rows($result); /* Function use for fetching rows */
    if($rows==1){
      /* ACCESS FOR ADMIN */
      if($data->role_id==1){
        session_id("session1");
        session_start();
        $_SESSION['sessId1'] = session_id();
        $_SESSION['userId'] = $data->userId;
        $_SESSION['userFname'] = $data->userFname;
        $_SESSION['userLname'] = $data->userLname;
        $_SESSION['role_id'] = $data->role_id;
        echo "<script>alert('Admin Login Successfully...')</script>";
        echo "<script>window.location.href='admin/dashboard.php'</script>";
      }
      elseif($data->role_id==2){
        session_id("session2");
        session_start();
        $_SESSION['sessId2'] = session_id();
        $_SESSION['userId'] = $data->userId;
        $_SESSION['userFname'] = $data->userFname;
        $_SESSION['userLname'] = $data->userLname;
        $_SESSION['userAdhar'] = $data->userAdhar;
        $_SESSION['role_id'] = $data->role_id;
        echo "<script>alert('Receptionist Login Successfully...')</script>";
        echo "<script>window.location.href='receptionist/dashboard.php'</script>";
      }
      elseif($data->role_id==3){
        session_id("session3");
        session_start();
        $_SESSION['sessId3'] = session_id();
        $_SESSION['userId'] = $data->userId;
        $_SESSION['userFname'] = $data->userFname;
        $_SESSION['userLname'] = $data->userLname;
        $_SESSION['userAdhar'] = $data->userAdhar;
        $_SESSION['role_id'] = $data->role_id;
        echo "<script>alert('Donor Login Successfully...')</script>";
        echo "<script>window.location.href='donor/dashboard.php'</script>";
      }
      elseif($data->role_id==4){
        session_id("session4");
        session_start();
        $_SESSION['sessId4'] = session_id();
        $_SESSION['userId'] = $data->userId;
        $_SESSION['userFname'] = $data->userFname;
        $_SESSION['userLname'] = $data->userLname;
        $_SESSION['userAdhar'] = $data->userAdhar;
        $_SESSION['role_id'] = $data->role_id;
        echo "<script>alert('Receiver Login Successfully...')</script>";
        echo "<script>window.location.href='receiver/dashboard.php'</script>";
      }
    }
    else{
      if($rows < 1){
        echo "<script>alert('Invalid credentials please try again...')</script>";
        echo "<script>window.history.back()</script>";
      }
      else{
        echo "<script>alert('More than one entries found...')</script>";
        echo "<script>window.history.back()</script>";
      }
    }
  }
?>