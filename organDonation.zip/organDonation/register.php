<?php 
  require "include/connection.php";
  $result = $con->query("SELECT * FROM role");
  $userResult = $con->query("SELECT * FROM users WHERE deleted_at = 1 AND role_id = 1");
  $userData = $userResult->fetch_object();
 /*  echo "<pre>";
  print_r($userData);
  exit; */
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="public/css/style.css">

    <title>Register Page</title>
  </head>
  <body>
    <div class="container">
      <div class="row mt-5">
        <div class="col-md-8 mx-auto">
          <div class="card shadow">
            <div class="card-header border-bottom  text-center border-primary bg-primary">
              <h2 class="card-title text-white d-inline" role="button">Organ Donate</h2>
            </div>
            <form name="userForm" method="post" action="admin/getdata.php" onSubmit="return formValidate()">
              <div class="card-body">
                <div class="form-group">
                  <label for="inputFirstName">First Name</label>
                  <input type="text" name="fname" class="form-control" id="inputFirstName" placeholder="Enter First Name">
                </div>
                <div class="form-group">
                  <label for="inputLastName">Last Name</label>
                  <input type="text" name="lname" class="form-control" id="inputLastName" placeholder="Enter Last Name">
                </div>
                <div class="form-group">
                  <label for="inputAge">Age</label>
                  <input type="number" name="age" class="form-control" id="inputAge" placeholder="Enter Age">
                </div>
                <div class="form-group">
                  <label for="inputEmail">Email address</label>
                  <input type="email" name="email" class="form-control" id="inputEmail" placeholder="Enter Email">
                  <small class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                  <label for="inputPassword">Password</label>
                  <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Enter Password">
                </div>
                <div class="form-group">
                  <label for="inputAddress1">Address Line 1</label>
                  <input type="text" name="add1" class="form-control" id="inputAddress1" placeholder="House No, Street Name">
                </div>
                <div class="form-group">
                  <label for="inputAddress2">Address Line 2</label>
                  <input type="text" name="add2" class="form-control" id="inputAddress2" placeholder="Landmark, Road">
                </div>
                <div class="form-group">
                  <label for="inputCity">City</label>
                  <input type="text" name="city" class="form-control" id="inputCity" placeholder="Enter City">
                </div>
                <div class="form-group">
                  <label for="inputMobile">Mobile Number</label>
                  <input type="text" name="mobile" class="form-control" id="inputMobile" placeholder="Enter Mobile">
                </div>
                <div class="form-group">
                  <label for="inputAdhar">Adhaar Card Number</label>
                  <input type="text" name="adhaar" class="form-control" id="inputAdhar" placeholder="Input Adhar Number">
                </div>
                <div class="form-group">
                  <label for="role_id">Register for What Role?</label>
                  <select name="role_id" id="role_id" class="form-control">
                    <option selected disabled>Select Any Role</option>
                    <?php
                      while($data=$result->fetch_object()){
                        if($data->roleId != 2){
                          if($data->roleId != $userData->role_id){
                            echo "<option value='$data->roleId'>$data->roleName</option>";
                          }
                        }
                      }
                    ?>
                  </select>
                </div>
              </div>
              <div class="card-footer bg-white border-top border-primary">
                <button type="submit" class="btn btn-success" name="userSubmit">Submit</button>
                <button type="reset" class="btn btn-danger ml-2" >Cancel</button>
                <p class="my-3 text-center">
                  Already have an account? <a href="index.php" class="text-primary">Please Sign in here!</a>
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="public/js/jquery.slim.min.js"></script>
    <script src="public/js/bootstrap.bundle.min.js"></script>
    <!-- Validation Link -->
    <script src="public/js/validation/userValidation.js"></script>
  </body>
</html>