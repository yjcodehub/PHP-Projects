function formValidate(){
  var fname=document.recForm.fname.value;
  var lname=document.recForm.lname.value;
  var age=document.recForm.age.value;
  var email=document.recForm.email.value;
  var password=document.recForm.password.value;
  var add1=document.recForm.add1.value;
  var add2=document.recForm.add2.value;
  var city=document.recForm.city.value;
  var mobile=document.recForm.mobile.value;
  var adhaar=document.recForm.adhaar.value;
  var role_id=document.recForm.role_id.value;
  if(fname == ''){
    alert('Fill First Name');
    document.recForm.fname.focus();
    return false;
  }else if(lname == ''){
    alert('Fill Last Name');
    document.recForm.lname.focus();
    return false;
  }else if(age == ''){
    alert('Fill Age');
    document.recForm.age.focus();
    return false;
  }else if(email == ''){
    alert('Fill Email');
    document.recForm.email.focus();
    return false;
  }else if(password == ''){
    alert('Fill Password');
    document.recForm.password.focus();
    return false;
  }else if(add1 == ''){
    alert('Fill Address line 1');
    document.recForm.add1.focus();
    return false;
  }else if(add2 == ''){
    alert('Fill Address Line 2');
    document.recForm.add2.focus();
    return false;
  }else if(city == ''){
    alert('Fill City');
    document.recForm.city.focus();
    return false;
  }else if(mobile == ''){
    alert('Fill Mobile');
    document.recForm.mobile.focus();
    return false;
  }else if(adhaar == ''){
    alert('Fill Adhaar Number');
    document.recForm.adhaar.focus();
    return false;
  }else if(role_id == ''){
    alert('Select Role');
    document.recForm.role_id.focus();
    return false;
  }
}