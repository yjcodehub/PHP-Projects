function formValidate(){
  var fname=document.userForm.fname.value;
  var lname=document.userForm.lname.value;
  var age=document.userForm.age.value;
  var email=document.userForm.email.value;
  var password=document.userForm.password.value;
  var add1=document.userForm.add1.value;
  var add2=document.userForm.add2.value;
  var city=document.userForm.city.value;
  var mobile=document.userForm.mobile.value;
  var adhaar=document.userForm.adhaar.value;
  var role_id=document.userForm.role_id.value;
  if(fname == ''){
    alert('Fill First Name');
    document.userForm.fname.focus();
    return false;
  }else if(lname == ''){
    alert('Fill Last Name');
    document.userForm.lname.focus();
    return false;
  }else if(age == ''){
    alert('Fill Age');
    document.userForm.age.focus();
    return false;
  }else if(email == ''){
    alert('Fill Email');
    document.userForm.email.focus();
    return false;
  }else if(password == ''){
    alert('Fill Password');
    document.userForm.password.focus();
    return false;
  }else if(add1 == ''){
    alert('Fill Address line 1');
    document.userForm.add1.focus();
    return false;
  }else if(add2 == ''){
    alert('Fill Address Line 2');
    document.userForm.add2.focus();
    return false;
  }else if(city == ''){
    alert('Fill City');
    document.userForm.city.focus();
    return false;
  }else if(mobile == ''){
    alert('Fill Mobile');
    document.userForm.mobile.focus();
    return false;
  }else if(adhaar == ''){
    alert('Fill Adhaar Number');
    document.userForm.adhaar.focus();
    return false;
  }else if(role_id == ''){
    alert('Select Role');
    document.userForm.role_id.focus();
    return false;
  }
}