function formValidate(){
  var email = document.loginForm.email.value;
  var password = document.loginForm.password.value;
  if(email==''){
    alert('Insert Email');
    document.loginForm.email.focus();
    return false;
  }else if(password==''){
    alert('Insert Password');
    document.loginForm.password.focus();
    return false;
  }
}