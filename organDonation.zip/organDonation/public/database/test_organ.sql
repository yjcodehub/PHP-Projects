-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2021 at 10:27 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_organ`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign`
--

CREATE TABLE `assign` (
  `assignId` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `receptionist_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `receiverId` int(11) NOT NULL,
  `assignOrgan` varchar(50) NOT NULL,
  `assignDate` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assign`
--

INSERT INTO `assign` (`assignId`, `donor_id`, `receptionist_id`, `receiver_id`, `receiverId`, `assignOrgan`, `assignDate`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 3, 5, 1, 8, 'Kidney', '2021-06-05', '2021-06-03 06:47:42', '2021-06-03 06:47:42', 1),
(2, 1, 5, 2, 8, 'Liver', '2021-06-05', '2021-06-03 06:50:10', '2021-06-03 06:50:10', 1),
(3, 4, 5, 5, 11, 'Heart', '2021-06-06', '2021-06-03 06:50:46', '2021-06-03 06:50:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `donorId` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `receptionist_id` int(11) NOT NULL,
  `donorOrgan` varchar(50) NOT NULL,
  `donorBloodGroup` varchar(10) NOT NULL,
  `donorHeight` int(5) NOT NULL,
  `donorWeight` int(5) NOT NULL,
  `donorStatus` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`donorId`, `donor_id`, `receptionist_id`, `donorOrgan`, `donorBloodGroup`, `donorHeight`, `donorWeight`, `donorStatus`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 9, 5, 'Liver', 'B+', 170, 65, 2, '2021-05-26 17:11:45', '2021-06-02 11:38:39', 1),
(2, 9, 5, 'Kidney', 'A+', 172, 67, 1, '2021-05-26 17:13:29', '2021-05-31 08:21:42', 0),
(3, 9, 5, 'Kidney', 'A+', 172, 67, 2, '2021-05-26 17:14:00', '2021-06-01 08:09:10', 1),
(4, 9, 5, 'Heart', 'O+', 175, 75, 2, '2021-05-26 17:15:32', '2021-06-03 06:50:32', 1),
(5, 9, 5, 'Ear', 'AB-', 180, 75, 1, '2021-05-26 17:22:34', '2021-05-26 17:22:34', 1),
(6, 9, 5, 'Eye', 'AB-', 180, 75, 0, '2021-05-26 17:23:18', '2021-06-01 08:23:18', 1),
(7, 9, 5, 'Eye', 'AB-', 180, 75, 0, '2021-05-26 17:24:17', '2021-06-01 08:36:57', 1),
(8, 9, 5, 'Hand Bones', 'AB+', 185, 40, 2, '2021-05-26 17:25:01', '2021-06-01 11:39:46', 1),
(9, 10, 5, 'Lungs', 'ABO+', 160, 60, 1, '2021-05-26 17:50:31', '2021-05-26 17:50:31', 1),
(10, 10, 5, 'Legs Bone', 'B-', 171, 71, 1, '2021-05-26 17:51:17', '2021-05-26 17:51:17', 1),
(11, 10, 5, 'PipeLine', 'A-', 155, 59, 1, '2021-05-26 17:51:45', '2021-05-26 17:51:45', 1),
(12, 9, 4, 'Leg Piece', 'O-', 145, 50, 1, '2021-05-26 18:00:45', '2021-05-26 18:00:45', 1);

-- --------------------------------------------------------

--
-- Table structure for table `receivers`
--

CREATE TABLE `receivers` (
  `receiverId` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `receptionist_id` int(11) NOT NULL,
  `receiverOrgan` varchar(50) NOT NULL,
  `receiverBloodGroup` varchar(10) NOT NULL,
  `receiverHeight` int(5) NOT NULL,
  `receiverWeight` int(5) NOT NULL,
  `receiverStatus` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receivers`
--

INSERT INTO `receivers` (`receiverId`, `receiver_id`, `receptionist_id`, `receiverOrgan`, `receiverBloodGroup`, `receiverHeight`, `receiverWeight`, `receiverStatus`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 8, 5, 'Kidney', 'A-', 172, 75, 4, '2021-06-01 09:01:40', '2021-06-03 06:47:42', 1),
(2, 8, 5, 'Liver', 'B+', 172, 65, 4, '2021-06-02 06:21:52', '2021-06-03 06:50:10', 1),
(3, 8, 5, 'Ears', 'AB+', 165, 70, 0, '2021-06-02 06:22:15', '2021-06-02 07:16:54', 1),
(4, 8, 5, 'Heart', 'B+', 160, 60, 2, '2021-06-02 06:22:41', '2021-06-02 11:45:46', 1),
(5, 11, 5, 'Heart', 'O-', 165, 65, 4, '2021-06-03 05:58:29', '2021-06-03 06:50:46', 1);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `roleId` int(11) NOT NULL,
  `roleName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `roleName`) VALUES
(1, 'Admin'),
(2, 'Receptionist'),
(3, 'Donor'),
(4, 'Reciever');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userFname` varchar(50) NOT NULL,
  `userLname` varchar(50) NOT NULL,
  `userAge` int(3) NOT NULL,
  `userEmail` varchar(100) NOT NULL,
  `userPassword` varchar(100) NOT NULL,
  `userAddress1` varchar(100) NOT NULL,
  `userAddress2` varchar(100) NOT NULL,
  `userCity` varchar(50) NOT NULL,
  `userMobile` bigint(15) NOT NULL,
  `userAdhar` bigint(15) NOT NULL,
  `role_id` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userFname`, `userLname`, `userAge`, `userEmail`, `userPassword`, `userAddress1`, `userAddress2`, `userCity`, `userMobile`, `userAdhar`, `role_id`, `created_at`, `modified_at`, `deleted_at`) VALUES
(1, 'Super', 'Admin', 50, 'admin@gmail.com', '4de93544234adffbb681ed60ffcfb941', 'Manewada', 'Trimurti Nagar', 'Nagpur', 4569871230, 789456123012, 1, '2021-05-18 09:51:05', '2021-05-22 10:44:46', 1),
(2, 'John', 'Smith', 30, 'johnsmith@gmail.com', '202cb962ac59075b964b07152d234b70', 'America', 'Maxico', 'Florida', 8574963210, 79456123012, 2, '2021-05-18 09:55:48', '2021-05-18 09:55:48', 1),
(3, 'Mahendra', 'Dhoni', 30, 'mahendra@gmail.com', '68053af2923e00204c3ca7c6a3150cf7', 'Kanjiwali', 'Near Rich House', 'Mumbai', 7485961230, 753941263259, 2, '2021-05-18 09:57:47', '2021-05-19 16:28:54', 1),
(4, 'Virat', 'Kohli', 40, 'virat@gmail.com', '250cf8b51c773f3f8dc8b4be867a9a02', 'Boriwadi', 'Kalamna', 'Nagpur', 8574961230, 7418529630123, 2, '2021-05-18 10:28:32', '2021-05-18 11:00:01', 1),
(5, 'YASH', 'JAIS', 23, 'yash@gmail.com', '202cb962ac59075b964b07152d234b70', 'Juni Shukrawari', 'Near Gandhi Statue', 'Nagpur', 9359021763, 1234567891011, 2, '2021-05-19 16:44:23', '2021-05-23 06:04:36', 1),
(6, 'Kunal', 'Jais', 27, 'kunal@gmail.com', 'ca94aa55199b6b4a96f0b2611f71aa38', 'Mahal', 'Tulsibagh', 'Nagpur', 7418529630, 745896321452, 3, '2021-05-20 16:40:24', '2021-05-20 16:40:24', 1),
(7, 'Shubham', 'Shahu', 22, 'shubham@gmail.com', '0fff93b552c82a414792be60d1b4372c', 'Mahal', 'Tulsibgh', 'Nagpur', 7485961230, 855985548556, 3, '2021-05-20 16:43:58', '2021-05-20 16:43:58', 1),
(8, 'Akhil', 'Thakre', 23, 'akhil@gmail.com', '3f81c69607d3f4d5672101685e3c1f6b', 'Shri Krishna Nagar', 'Near KDK', 'Nagpur', 8965741235, 744589965224, 4, '2021-05-20 17:17:50', '2021-05-20 17:17:50', 1),
(9, 'Raghuvanshi', 'Joshi', 30, 'raghu@gmail.com', 'd92451fe64f0546cb0d0056df29f167a', 'Near Futala Talab', 'Near Ambazari Garden', 'Nagpur', 7845129630, 874598565412, 3, '2021-05-22 11:54:11', '2021-05-23 06:16:06', 1),
(10, 'Pratiksha', 'Bawane', 25, 'pratiksha@gmail.com', '44ada58a0eed2fd662d209b95d99eeba', 'Wardhaman Nagar', 'Near Lata Mangeshkar Hospital', 'Nagpur', 7418529632, 7418525632652, 3, '2021-05-22 11:59:47', '2021-05-22 11:59:47', 1),
(11, 'Shubham', 'Somanthe', 26, 'shubham@gmail.com', '202cb962ac59075b964b07152d234b70', 'area 61', 'Near landmark chowk', 'Nagpur', 7545856595, 78459658952136, 4, '2021-06-03 05:57:18', '2021-06-03 05:57:18', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assign`
--
ALTER TABLE `assign`
  ADD PRIMARY KEY (`assignId`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`donorId`);

--
-- Indexes for table `receivers`
--
ALTER TABLE `receivers`
  ADD PRIMARY KEY (`receiverId`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`roleId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assign`
--
ALTER TABLE `assign`
  MODIFY `assignId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `donorId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `receivers`
--
ALTER TABLE `receivers`
  MODIFY `receiverId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `roleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
