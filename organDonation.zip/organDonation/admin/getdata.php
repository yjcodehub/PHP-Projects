<?php 
  error_reporting(0);
  require "../include/connection.php";
  if(isset($userSubmit)){
    echo "<pre>";
    /* print_r($_POST); //To display array 
    $fname = $_POST['fname'];
    exit; */
    $password = md5($password);/* Function ue for Encryption */

    $query = "INSERT INTO users VALUES(NULL, '$fname', '$lname','$age','$email','$password','$add1','$add2','$city','$mobile','$adhaar','$role_id',NOW(),NOW(),1)";
    $result = $con->query("SELECT * FROM users WHERE role_id = 1 AND deleted_at = 1");
    $data = $result->fetch_object();

    /* TO CHECK if ADMIN IS ALREADY AVAILABLE */
    if($role_id == $data->role_id){
      echo "<script>alert('Admin Already Registered')</script>";
      echo "<script>window.history.back()</script>";
    }
    else{
      if($con->query($query)){
        echo "<script>alert('Register Successfully')</script>";
        if($role_id==1){
          echo "<script>window.location.href='../index.php'</script>";
        }elseif($role_id==2){
          echo "<script>window.location.href='manageReceptionist.php'</script>";
        }elseif($role_id==3){
          echo "<script>window.location.href='../index.php'</script>";
        }elseif($role_id==4){
          echo "<script>window.location.href='../index.php'</script>";
        }
      }
      else{
        echo "<script>alert('Something went wrong')</script>";
        echo "<script>window.history.back()</script>";
      }
    }
    
  }
  
?>