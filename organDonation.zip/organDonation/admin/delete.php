<?php
  require "session.php";
  require "../include/connection.php"; 
  if(isset($userId)){
    $query = "UPDATE users SET modified_at=NOW(), deleted_at=0 WHERE userId=$userId";
    if($con->query($query)){
      echo "<script>alert('Record Deleted...')</script>";
      echo "<script>window.location.href='manageReceptionist.php'</script>";
    }
  }
?>